<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends MX_Controller
{

	function __construct() {
		parent::__construct();
		$this->load->model('mdl_admin');
	}

	function login(){
		$getLoggedStatus = Modules::run('site_security/is_admin');

		if(!$getLoggedStatus)
			$this->load->view('login');
		else
			redirect('dashboard/home','refresh');
	}

	function _authenticate($username){
		$query = $this->get_where_custom('username', $username);
		
		foreach ($query->result() as $row) {
			$userId = $row->userId;
			$userType = $row->userType;
			$userName = $row->username;
		}
		
		$sessionData = array('userId'=>$userId,	'userType'=>$userType, 'userName'=>$userName);
		$this->session->set_userdata('adminData', $sessionData);
		redirect('dashboard/home');
	}

	function submit(){

		if($this->input->post()):
			$this->load->library('form_validation');

			$this->form_validation->set_rules('username', 'Username', 'trim|required|max_length[30]|xss_clean');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_password_check');
			
			if ($this->form_validation->run($this) == FALSE){
				$this->login();
			}
			else{
				$username = $this->input->post('username');
				$this->_authenticate($username);
			}
		else:
			show_404();
		endif;

	}

	function password_check($password){
		$username = $this->input->post('username');
		$password = Modules::run('site_security/_makeHash', $password);
		
		$isAdmin = $this->mdl_admin->checkLogin($username, $password);

		if(!$isAdmin){
			$this->form_validation->set_message('password_check','Username and password don\'t match');
			return FALSE;
		}
		else{
			return TRUE;
		}
	}

	function logout(){
		$sessionData = array('userId'=>'', 'userType'=>'');
		$this->session->unset_userdata('adminData', $sessionData);
		$this->session->sess_destroy();
     	redirect('admin/login','refresh');
	}

	function get_where_custom($col, $value) {
		$query = $this->mdl_admin->get_where_custom($col, $value);
		return $query;
	}

	function _insert($data) {
		return $this->mdl_admin->_insert($data);
	}

	function _update($id, $data) {
		return $this->mdl_admin->_update($id, $data);
	}

	function _delete($id) {
		return $this->mdl_admin->_delete($id);
	}
}