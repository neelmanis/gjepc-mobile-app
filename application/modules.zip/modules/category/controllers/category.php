<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Category extends MX_Controller
{
	function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_category');	

	}

	function _getWhere($data = array()){
		return $this->mdl_category->get_where($data);
	}

	function _getSlug($catId = 0){
		$result = $this->mdl_category->get_where(array('catId'=>$catId));
		return $result[0]->slug;
	}

	function _getName($catId = 0){
		$result = $this->mdl_category->get_where(array('catId'=>$catId));
		return $result[0]->name;
	}
	
	function lists($status = 'active')
	{
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'categories';
		$data['menu'] = 'lists';

		$isActive = ($status == 'active') ? '1' : '0';

		$getCategories = $this->mdl_category->get_where(array('isActive'=>$isActive));
		$data['getAllCategories'] = $getCategories;
		echo Modules::run('template/'.$template, $data);
	}

	function add(){
		$template = 'admin';
		$data['viewFile'] = "add";
		$data['page'] = 'categories';
		$data['menu'] = 'add';

		echo Modules::run('template/'.$template, $data);
	}

	function edit($catId){
		$template = 'admin';
		$data['viewFile'] = "edit";
		$data['page'] = 'categories';
		$data['menu'] = 'edit';
		$catId = intval($catId);

		$getCategories = $this->mdl_category->get_where(array('catId'=>$catId));
		$data['categories'] = $getCategories[0];
		$data['status'] = $getCategories[0]->isActive;
		echo Modules::run('template/'.$template, $data);
	}

	function jsonCategories(){
		$new = array(); $json = array();
		$categories = $this->mdl_category->_conditions(array('isActive'=>'1'), array('parentId'=>0, 'parentId'=>1));

		foreach($categories as $category){
			$new['id'] = $category->catId;
			$new['text'] = $category->name;

			array_push($json, $new);
		}
		echo json_encode($json);
	}

	function newcategory(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_category->newcategory();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success')
					echo 'success';
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function editcategory(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_category->editcategory();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success') {
					$this->session->set_flashdata('success', 'Category Updated Successfully!!!');
					echo 'success';
				}
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function delcategory($catId){
		if(Modules::run('site_security/is_admin')):
			$catId = intval($catId);
			if($this->mdl_category->_delete($catId))
				echo 'success';
			else
				echo 'failure';
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function view($slug = ''){
		$template = 'twoColLeft';
		$data['viewFile'] = "listing";

		$categories = $this->mdl_category->get_where(array('slug'=>$slug,'isActive'=>'1'));
		$data['categories'] = $categories[0];

		$catId = $categories[0]->catId;
		$subcategories = $this->mdl_category->get_where(array('parentId'=>$catId,'isActive'=>'1'));

		$data['breadcrumb'] = $categories[0]->name;
		$data['title'] = 'EASYRENTIL - '.$categories[0]->name;
		$data['leftPanel'] = 'filters';

		if(sizeof($subcategories))
			$data['subcategories'] = $subcategories;

		echo Modules::run('template/'.$template, $data);
	}
}

