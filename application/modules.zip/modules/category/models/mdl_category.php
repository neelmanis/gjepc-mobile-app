<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mdl_category extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	function get_table() {
		$table = "category_master";
		return $table;
	}

	function _insert($data) {
		$table = $this->get_table();
		return $this->db->insert($table, $data);
	}

	function _update($catId, $data) {
		$table = $this->get_table();
		$this->db->where('catId', $catId);
		return $this->db->update($table, $data);
	}

	function _delete($catId) {
		if($catId > 1):
			$table = $this->get_table();
			$this->db->where('catId', $catId);
			return $this->db->delete($table);
		else:
			return false;
		endif;
	}

	function get_where($filters = array()) {
		$table = $this->get_table();

		if(sizeof($filters)){
			foreach($filters as $key=>$value)
				$this->db->where($key, $value);

			$query = $this->db->get($table);
			return $query->result();
		}
		else
			return FALSE;
	}

	function _conditions($and = array(), $or = array()){
		$table = $this->get_table();
		$andconditon = FALSE; $orcondition = FALSE;

		if(sizeof($and)){
			$andconditon = TRUE;
			foreach($and as $key=>$value)
				$this->db->where($key, $value);
		}

		if(sizeof($or)){
			$orcondition = TRUE;
			foreach($or as $key=>$value)
				$this->db->or_where($key, $value);
		}

		if($orcondition || $andconditon){
			$query = $this->db->get($table);
			return $query->result();
		}

		return FALSE;
	}

	function newcategory(){

		$this->form_validation->set_rules('name','Category Name','trim|required|max_length[100]|xss_clean');
		$this->form_validation->set_rules('slug','Url Key','trim|required|is_unique[category_master.slug]|max_length[150]|xss_clean');
		$this->form_validation->set_rules('parentId','Parent Category','trim|required|is_natural|xss_clean');
		$this->form_validation->set_rules('isActive','Status','trim|required|is_natural|xss_clean');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');

		if(!$this->form_validation->run())
			return 'validationErrors';
		else{
			/*after form validation check for image validation if validated insert data else throw error*/
			if(!empty($_FILES['icon']['name'])):
				$upload = upload(array('name'=>'icon', 'upload_path'=>'category/icons', 'max_width'=>32, 'max_height'=>32 ));
				if(array_key_exists('errors', $upload))
					return 'Icon: '.$upload['errors'];

				$_POST['icon'] = $upload['filename'];
			endif;

			if(!empty($_FILES['thumb']['name'])):
				$thumb = upload(array('name'=>'thumb', 'upload_path'=>'category/tiles', 'max_width'=>342, 'max_height'=>272 ));
				if(array_key_exists('errors', $thumb))
					return 'Tile Image: '.$thumb['errors'];

				$_POST['thumb'] = $thumb['filename'];
			endif;

			$_POST['createdDate'] = date('Y-m-d h:i:s');
			$_POST['modifiedDate'] = date('Y-m-d h:i:s');

			if($this->_insert($this->input->post())):
				return 'success';
			else:
				return 'failed';
			endif;
		}
	}

	function editcategory(){

		$this->form_validation->set_rules('catId','Category','trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('name','Category Name','trim|required|max_length[100]|xss_clean');

		if($_POST['slugCompare'] != $_POST['slug'])
			$this->form_validation->set_rules('slug','Url Key','trim|required|is_unique[category_master.slug]|max_length[150]|xss_clean');
		else
			$this->form_validation->set_rules('slug','Url Key','trim|required|max_length[150]|xss_clean');

		$this->form_validation->set_rules('parentId','Parent Category','trim|required|is_natural|xss_clean');
		$this->form_validation->set_rules('isActive','Status','trim|required|is_natural|xss_clean');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');
		$this->form_validation->set_message('numeric', '%s Invalid');

		if(!$this->form_validation->run())
			return 'validationErrors';
		else{
			/*after form validation check for image validation if validated insert data else throw error*/
			if(!empty($_FILES['icon']['name'])):
				$upload = upload(array('name'=>'icon', 'upload_path'=>'category/icons', 'max_width'=>32, 'max_height'=>32 ));
				if(array_key_exists('errors', $upload))
					return 'Icon: '.$upload['errors'];

				$_POST['icon'] = $upload['filename'];
			endif;

			if(!empty($_FILES['thumb']['name'])):
				$thumb = upload(array('name'=>'thumb', 'upload_path'=>'category/tiles', 'max_width'=>342, 'max_height'=>272 ));
				if(array_key_exists('errors', $thumb))
					return 'Tile Image: '.$thumb['errors'];

				$_POST['thumb'] = $thumb['filename'];
			endif;

			$_POST['modifiedDate'] = date('Y-m-d h:i:s');
			unset($_POST['slugCompare']);

			$catId = $this->input->post('catId');

			if($this->_update($catId, $this->input->post())):
				return 'success';
			else:
				return 'failed';
			endif;
		}
	}
}