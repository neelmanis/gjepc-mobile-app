<div class="catagoryFilters">
    <?php if(isset($subcategories)){ ?>
    <div class="widget"> <strong class="title">Categories</strong>
        <ul class="listing">
            <?php foreach($subcategories as $subcategory): ?>
            <li><a href="#"><?php echo $subcategory->name ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php } ?>
    <div class="widget"> <strong class="title">Price Range</strong>
        <ul class="listing">
            <li><a href="#" class="active"><i class="fa fa-rupee"></i>. 50 - <i class="fa fa-rupee"></i>. 150 (4)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 150 - <i class="fa fa-rupee"></i>. 250 (3)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 250 - <i class="fa fa-rupee"></i>. 350 (7)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 350 - <i class="fa fa-rupee"></i>. 450 (14)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 450 - <i class="fa fa-rupee"></i>. 550 (10)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 550 - <i class="fa fa-rupee"></i>. 650 (5)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 650 - <i class="fa fa-rupee"></i>. 750 (3)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 750 - <i class="fa fa-rupee"></i>. 850 (8)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 850 - <i class="fa fa-rupee"></i>. 950 (12)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 950 - <i class="fa fa-rupee"></i>. 1,050 (4)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 1,050 - <i class="fa fa-rupee"></i>. 1,150 (1)</a></li>
            <li><a href="#"><i class="fa fa-rupee"></i>. 1,150 - <i class="fa fa-rupee"></i>. 1,250 (9)</a></li>
        </ul>
    </div>
</div>