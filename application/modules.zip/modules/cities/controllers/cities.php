<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Cities extends MX_Controller
{
	function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_cities');

	}

	function _getName($cityId = 0){
		$result = $this->mdl_cities->get_where(array('cityId'=>$cityId));
		return $result[0]->name;
	}

	function jsonallcities(){
		$new = array(); $json = array();
		$array = $this->uri->uri_to_assoc();

		$isActive = (array_key_exists('status', $array)) ? (($array['status'] == 'active') ? '1':'0')  : '1';

		$cities = $this->mdl_cities->_conditions(array('isActive'=>$isActive));

		foreach($cities as $city){
			$new['name'] = $city->name;
			$new['state_id'] = $city->state_id;
			$new['stateName'] = Modules::run('states/_getName', $city->state_id);
			$new['country_id'] = $city->country_id;
			$new['countryName'] = Modules::run('countries/_getName',$city->country_id);
			$new['isActive'] = ($city->isActive) ? 'Active':'De-activated';
			$new['cityId'] = $city->cityId;


			array_push($json, $new);
		}
		echo json_encode($json);
	}

	function collection($id = 0){
		if(isset($_POST['isAjax'])) {
			$id = intval($id);
			$state_id = intval($_POST['state_id']);
			$result = $this->mdl_cities->get_where(array('cityId !=' => $id, 'state_id'=>$state_id, 'isActive'=> '1'));
			echo json_encode($result);
		}
		else{
			redirect('/');
		}
	}
	
	function lists($status = 'active')
	{
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'masters';
		$data['menu'] = 'city';
		$data['status'] = $status;

		echo Modules::run('template/'.$template, $data);
	}

	function add(){
		$template = 'admin';
		$data['viewFile'] = "add";
		$data['page'] = 'masters';
		$data['menu'] = 'city';

		echo Modules::run('template/'.$template, $data);
	}

	function edit($cityId){
		$template = 'admin';
		$data['viewFile'] = "edit";
		$data['page'] = 'masters';
		$data['menu'] = 'city';
		$cityId = intval($cityId);

		$cities = $this->mdl_cities->get_where(array('cityId'=>$cityId));
		$data['cities'] = $cities[0];
		$data['status'] = $cities[0]->isActive;
		echo Modules::run('template/'.$template, $data);
	}

	function newcity(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_cities->newcity();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success')
					echo 'success';
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function editcity(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_cities->editcity();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success') {
					$this->session->set_flashdata('success', 'City Updated Successfully!!!');
					echo 'success';
				}
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function delcity($cityId){
		if(Modules::run('site_security/is_admin')):
			$cityId = intval($cityId);
			if($this->mdl_cities->_delete($cityId))
				echo 'success';
			else
				echo 'failure';
		else:
			show_error(INVALID_PAGE);
		endif;
	}
}

