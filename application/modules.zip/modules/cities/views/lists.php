<div class="row mt">
    <div class="col-lg-12">
		<div class="alert alert-danger errorMsg hide alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			"<b>Oops. </b>Something went wrong. Please try again later."
		</div>
		<?php if(!empty($this->session->flashdata('success'))): ?>
		<div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<?php echo $this->session->flashdata('success'); ?>
		</div>
		<?php endif; ?>

        <div class="content-panel">
			<h4>Cities</h4>
			<div class="showback">
				<a type="button" class="btn btn-primary" href="<?php echo base_url('cities/add')?>"><i class="fa fa-plus"></i> Add New</a>
				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
						View <span class="caret"></span>
					</button>
					<ul class="dropdown-menu" role="menu">
						<li><a href="<?php echo base_url("cities/lists/active"); ?>">Active Cities</a></li>
						<li><a href="<?php echo base_url("cities/lists/inactive"); ?>">De-activated Cities</a></li>
					</ul>
				</div>
			</div>

			<section id="no-more-tables">
	            <table class="table table-striped table-condensed cf" id='listTable'>
					<thead class="cf">
						<tr>
							<th>Name</th>
							<th>State ID</th>
							<th>State</th>
							<th>Country ID</th>
							<th>Country</th>
							<th>isActive</th>
							<th><i class=" fa fa-edit"></i> Actions</th>
						</tr>
					</thead>
	        	</table>
			</section>
        </div>
    </div>
</div>
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">Delete State</h4>
				</div>
				<div class="modal-body">
					<p>Are you sure you want to <b class='name'></b> ?</p>
				</div>
				<div class="modal-footer">
					<button class="btn btn-default" data-dismiss="modal">Close</button>
					<button class="btn btn-danger" id=''>Delete</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script>

	$('#listTable').DataTable({
		stateSave: true,
		"ajax": {
			"url": baseUrl+"cities/jsonallcities/status/<?php echo $status ?>",
			"dataSrc": "",
			"deferRender": true
		},
		"columns": [
			{ "data": "name" },
			{ "data": "state_id" },
			{ "data": "stateName" },
			{ "data": "country_id" },
			{ "data": "countryName" },
			{ "data": "isActive" },
			{ "data": "cityId" }
		],
		"order": [[1, "asc"]],
		"columnDefs": [
			{
				"targets": [1],
				"visible": false,
				"searchable": false,
				"orderData": [ 1, 3 ]
			},
			{
				"targets": [3],
				"visible": false,
				"searchable": false,
				"orderData": [ 3, 1 ]
			},
			{
				"render": function ( data, type, row ) {
					var url = baseUrl + 'cities/edit/' + data;
					var str = '<a class="deleterows btn btn-danger btn-xs" data-target="#deleteModal" data-toggle="modal" data-id="'+ data +'" data-text="' + row.name + '" title="Delete City"><i class="fa fa-trash-o"></i></a>';
					str += ' <a class="btn btn-primary btn-xs" href="' + url + '" title="Edit City"><i class="fa fa-pencil"></i></a>';

					return str;
				},
				"targets": [6]
			}
		],
	});

	/* Setting up the delete button in modal box by adding id attribute to delete button in modal */
	jQuery(document).on('click', 'a.deleterows',function(){
		var $this = jQuery(this);
		var deleteModal = jQuery('#deleteModal');
		var text = $this.data('text');
		var dataid = $this.data('id');

		deleteModal.find('button.btn-danger').attr('id', dataid).end().find('b.name').text(text);
	})

	/* Click on delete button in delete Modal */
	jQuery('#deleteModal').find('button.btn-danger').on('click',function(e){
		e.preventDefault();
		var $this = jQuery(this);
		var id = $this.attr('id');

		$.ajax({
			url: baseUrl+'cities/delcity/'+id,
			success: function(data){
				if(data == 'success'){
					$this.siblings('button').trigger('click');
					jQuery('.errorMsg').addClass('hide');
					location.reload(true);
				}
				else{
					$this.siblings('button').trigger('click');
					jQuery('.errorMsg').removeClass('hide');
				}
			}
		})
	});
</script>