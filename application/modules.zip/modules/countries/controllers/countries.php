<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Countries extends MX_Controller
{
	function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_countries');

	}

	function _getName($countryId = 0){
		$result = $this->mdl_countries->get_where(array('countryId'=>$countryId));
		return $result[0]->countryName;
	}

	function jsoncountry(){
		$new = array(); $json = array();
		$countries = $this->mdl_countries->_conditions(array('isActive'=>'1'));

		foreach($countries as $country){
			$new['id'] = $country->countryId;
			$new['text'] = $country->countryName;

			array_push($json, $new);
		}
		echo json_encode($json);
	}

	function collection($id = 0){
		if(isset($_POST['isAjax'])) {
			$id = intval($id);
			$result = $this->mdl_countries->get_where(array('countryId !=' => $id, 'isActive'=> '1'));
			echo json_encode($result);
		}
		else{
			redirect('/');
		}
	}
	
	function lists($status = 'active')
	{
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'masters';
		$data['menu'] = 'country';

		$isActive = ($status == 'active') ? '1' : '0';

		$getcountries = $this->mdl_countries->get_where(array('isActive'=>$isActive));
		$data['getcountries'] = $getcountries;
		echo Modules::run('template/'.$template, $data);
	}

	function add(){
		$template = 'admin';
		$data['viewFile'] = "add";
		$data['page'] = 'masters';
		$data['menu'] = 'country';

		echo Modules::run('template/'.$template, $data);
	}

	function edit($countryId){
		$template = 'admin';
		$data['viewFile'] = "edit";
		$data['page'] = 'masters';
		$data['menu'] = 'country';
		$countryId = intval($countryId);

		$getcountries = $this->mdl_countries->get_where(array('countryId'=>$countryId));
		$data['country'] = $getcountries[0];
		$data['status'] = $getcountries[0]->isActive;
		echo Modules::run('template/'.$template, $data);
	}

	function newcountry(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_countries->newcountry();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success')
					echo 'success';
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function editcountry(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_countries->editcountry();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success') {
					$this->session->set_flashdata('success', 'Country Updated Successfully!!!');
					echo 'success';
				}
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function delcountry($countryId){
		if(Modules::run('site_security/is_admin')):
			$countryId = intval($countryId);
			if($this->mdl_countries->_delete($countryId))
				echo 'success';
			else
				echo 'failure';
		else:
			show_error(INVALID_PAGE);
		endif;
	}
}

