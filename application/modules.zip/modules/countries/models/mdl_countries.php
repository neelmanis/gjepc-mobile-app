<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mdl_countries extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	function get_table() {
		$table = "country_master";
		return $table;
	}

	function _insert($data) {
		$table = $this->get_table();
		return $this->db->insert($table, $data);
	}

	function _update($countryId, $data) {
		$table = $this->get_table();
		$this->db->where('countryId', $countryId);
		return $this->db->update($table, $data);
	}

	function _delete($countryId) {
		$table = $this->get_table();
		$this->db->where('countryId', $countryId);
		return $this->db->delete($table);
	}

	function resetCountry(){
		$results = $this->get_where(array('isDefault'=>'1'));

		if(sizeof($results)) {
			foreach ($results as $result)
				$this->_update($result->countryId, array('isDefault' => '0'));

			return TRUE;
		}
		return FALSE;
	}

	function get_where($filters = array()) {
		$table = $this->get_table();

		if(sizeof($filters)){
			$this->db->where($filters);

			$query = $this->db->get($table);
			return $query->result();
		}
		else
			return FALSE;
	}

	function _conditions($and = array(), $or = array()){
		$table = $this->get_table();
		$andconditon = FALSE; $orcondition = FALSE;

		if(sizeof($and)){
			$andconditon = TRUE;
			foreach($and as $key=>$value)
				$this->db->where($key, $value);
		}

		if(sizeof($or)){
			$orcondition = TRUE;
			foreach($or as $key=>$value)
				$this->db->or_where($key, $value);
		}

		if($orcondition || $andconditon){
			$query = $this->db->get($table);
			return $query->result();
		}

		return FALSE;
	}

	function newcountry(){

		$this->form_validation->set_rules('countryName','Country Name','trim|required|max_length[100]|xss_clean');
		$this->form_validation->set_rules('countryCode','Country Code','trim|required|max_length[10]|is_unique[country_master.countryCode]|xss_clean');
		$this->form_validation->set_rules('isDefault','Set as Default','trim|required|is_natural|xss_clean');
		$this->form_validation->set_rules('isActive','Status','trim|required|is_natural|xss_clean');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');

		if(!$this->form_validation->run())
			return 'validationErrors';
		else{
			$_POST['createdDate'] = date('Y-m-d h:i:s');
			$_POST['modifiedDate'] = date('Y-m-d h:i:s');

			if($this->_insert($this->input->post())):
				/* logic to reset default country */
				if($this->input->post('isDefault') == '1'){
					$countryId = $this->db->insert_id();

					if($this->resetCountry())
						$this->_update($countryId, array('isDefault'=>'1'));
				}
				return 'success';
			else:
				return 'failed';
			endif;
		}
	}

	function editcountry(){

		$this->form_validation->set_rules('countryId','Country','trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('countryName','Country Name','trim|required|max_length[100]|xss_clean');

		if($_POST['countryCodeCompare'] == $_POST['countryCode'])
			$this->form_validation->set_rules('countryCode','Country Code','trim|required|max_length[10]|xss_clean');
		else
			$this->form_validation->set_rules('countryCode','Country Code','trim|required|max_length[10]|is_unique[country_master.countryCode]xss_clean');

		$this->form_validation->set_rules('isDefault','Set as Default','trim|required|is_natural|xss_clean');
		$this->form_validation->set_rules('isActive','Status','trim|required|is_natural|xss_clean');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');
		$this->form_validation->set_message('numeric', '%s Invalid');

		if(!$this->form_validation->run())
			return 'validationErrors';
		else{
			/* logic to reset default country */
			if($this->input->post('isDefault') == '1')
				$this->resetCountry();

			$_POST['modifiedDate'] = date('Y-m-d h:i:s');
			unset($_POST['countryCodeCompare']);
			$countryId = $this->input->post('countryId');

			if($this->_update($countryId, $this->input->post())):
				return 'success';
			else:
				return 'failed';
			endif;
		}
	}
}