<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends MX_Controller
{
	function __construct() {
		parent::__construct();
	}

	function home(){
		$template = 'admin';
		$data = array();
		$data['viewFile'] = 'home';
		$data['page'] = 'dashboard';
		$data['menu'] = '';
		echo Modules::run('template/'.$template, $data); 
	}

	function profile(){
		if(Modules::run('site_security/isLoggedIn')):
			$template = 'membersArea';
			$data = array();
			$data['viewFile'] = 'userhome';
			$data['leftPanel'] = 'sidebar';
			$data['breadcrumb'] = "Dashboard";
			$data['title'] = 'EASYRENTIL - DASHBOARD';
			$data['page'] = 'Dashboard';
			$data['regId'] = Modules::run('site_security/_getUserIdfromSession');
			$data['info'] = Modules::run('users/_getWhere', array('regId'=>$data['regId']));

			echo Modules::run('template/_'.$template, $data);
		else:
			redirect('users/login');
		endif;

	}
}