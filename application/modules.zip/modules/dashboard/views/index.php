dashboard
<?php exit; ?>
<b><i><?php echo anchor('users/logout', 'Log Out'); ?></i></b>

<ul>

	<li><?php echo anchor('users/manage', 'Profile'); ?></li>

</ul>