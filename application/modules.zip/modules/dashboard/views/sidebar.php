<?php $profilePhoto = $info[0]->profilePhoto; ?>
<?php $pic = (empty($profilePhoto) || !file_exists("uploads/users/$regId/$profilePhoto")) ? 'assets/images/nouser.jpg' : "uploads/users/$regId/$profilePhoto"; ?>
<div class="userPanel">
    <div class="userPic"><img src="<?php echo base_url($pic); ?>"></div>
    <div class="userArea">
        <div class="userName"><?php echo $info[0]->firstName . ' ' . $info[0]->lastName; ?></div>
        <div class="userLinks">
            <a href="#" class="orange">View Profile</a>
            <a href="#" class="blue">Edit Profile</a>
        </div>
    </div>
</div>