<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Email extends MX_Controller
{
	function __construct() {
		parent::__construct();
	}

	function _mailer($data){
		$config = array(
			'host' => 'smtp',
			'smtp_host'=>'smtp.gmail.com',
			'smtp_port'=>465,
			'smtp_user'=>'tutorialslearn@gmail.com',
			'smtp_pass'=>'9867771084'
			);

		$message =  $this->load->view($data['viewFile'], $data, TRUE);

		$this->load->library('email', $config);
		$this->email->set_mailtype('html');
		$this->email->set_newline('/r/n');

		$this->email->from('tutorialslearn@gmail.com', 'Sachin Mishra');
		$this->email->to($data['receiverEmail']);
		$this->email->subject($data['subject']);
		$this->email->message($message);

		if($this->email->send())
			return TRUE;
		else
			return FALSE;
	}
}