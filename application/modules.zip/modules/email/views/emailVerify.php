<h3>Welcome To EasyRentil!!!</h3>

<p>Your Email needs to be verified, Please click on below Link to complete Verification Process.</p>
<br />
<p><a href='<?php echo base_url("users/everify/$encryptedString")?>'>Verify Your Email</a></p>
<br />
<p>Thanks !!!</p>