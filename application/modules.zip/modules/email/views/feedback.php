<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>decorama</title>
</head>

<body>
    <p>You have received a feedback from <?php echo $contactName; ?></p>
    <p>Email : <?php echo $email; ?></p>
    <p>PhoneNo : <?php echo $phoneNo; ?></p>
    <p>Message : <?php echo $message; ?></p>
</body>
</html>
