<h3>Welcome To EasyRentil!!!</h3>

<p>Thanks for registering with us, your application is pending approval from EasyRentil Admin.</p>
<p>We will notify once your application has been approved.</p>
<br />
<p>Please Verify your Email-Id by clicking on below link. </p>
<p><a href='<?php echo base_url("users/everify/$encryptedString")?>'>Verify Your Email</a></p>
<br />
<p>Thanks !!!</p>