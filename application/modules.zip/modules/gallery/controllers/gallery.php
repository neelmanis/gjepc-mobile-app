<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Gallery extends MX_Controller
{
	/*------------------------------ CONSTRUCTOR FUNCTION---------------------------------------*/
	function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_gallery');
	}
	
	    /**************** Upload  Content FUNCTION *********************************/
	   function uploadFile($imageName,$key,$folderName)
	   {
	   			$config['file_name'] = $imageName;
				$config['upload_path'] = './uploads/'.$folderName;
				$config['allowed_types'] = "gif|jpg|png|jpeg";
				$config['max_width']  = '2000';
				$config['max_height']  = '2000';
				
                $this->load->library('upload', $config);
				$this->upload->initialize($config);
				   
				 if (!$this->upload->do_upload($key))
					 {
						echo $this->upload->display_errors();
					 } else 
					 {
						//echo "insert";	 
					 }  
	   
	   }
	   /**************** Upload Content FUNCTION *********************************/	
	   
	   function delete_galleryname()
	   {
		   $galleryid      = $_POST['Banner_id'];
		$delete_banner = $this->mdl_gallery->gallery_delete($galleryid);
		echo "success";
	   }
	      function delete_galleryimagename()
	   {
		   $galleryid      = $_POST['Banner_id'];
		$delete_banner = $this->mdl_gallery->galleryimage_delete($galleryid);
		echo "success";
	   }
	
	function addgallery()	
	{
		$data['menu'] = 'add';	
		$data['viewFile']     = "addGallery";
		$data['page']         = 'gallery';
		$template             = 'admin';
		echo Modules::run('template/' . $template, $data);
	}  
	
	function gallerylists()	
	{
		$data['menu'] = 'lists';	
		$getName = $this->mdl_gallery->all_gallery_view();
		$data['getAllName'] = $getName;
		$data['viewFile']     = "view_galleryname";
		$data['page']         = 'gallery';
		$template             = 'admin';
		echo Modules::run('template/' . $template, $data);
	}  
	   
	function insertgallery()
	{
		$ans = $this->input->post();
		
		 $this->form_validation->set_rules('gallery','Gallery Name','required|is_unique[galleryname.name]');
		$this->form_validation->set_rules('banner_status','Status','required');
		$this->form_validation->set_rules('set_home','Set Default home','required');
	  
	   if($this->form_validation->run() == FALSE) 
		   {
			echo validation_errors();
		   } 
	   else
	     {
			$galleryName = $ans['gallery'];
			$status = $ans['banner_status'];
			$default = $ans['set_home'];
			if($default == '1')
				{
					$getDefault = $this->mdl_gallery->getDefaultRecord($default);	
				}	
			$data = array(
			'name' => $galleryName,
			'isactive' => $status,
			'isDefault' => $default,
			'createdDate' => date('Y-m-s'),
			'modifiedDate' => date('Y-m-s')
			);
	
			$inserdata = $this->mdl_gallery->insertGalleryName($data);
			echo $inserdata;
		 }
	}
		function edit_galleryname($id)
	{
		$get_single_banner_record = $this->mdl_gallery->get_gallery_single_data($id);
		$data['singlegallerydata']     = $get_single_banner_record;
		$data['viewFile']         = "editgallery";
		$data['menu']         = "edit";
		$data['page']             = "gallery";
		$template                 = 'admin';
		echo Modules::run('template/' . $template, $data);
	}
	   
	 	function updategallery()
	{
		$ans = $this->input->post();
		 $this->form_validation->set_rules('gallery','Gallery Name','required');
		$this->form_validation->set_rules('banner_status','Status','required');
	  
	   if($this->form_validation->run() == FALSE) 
		   {
			echo validation_errors();
		   } 
	   else
	     {
			$galleryName = $ans['gallery'];
			$status = $ans['banner_status'];
			$galleryId = $ans['galleryid'];
			
			$data = array(
			'name' => $galleryName,
			'isactive' => $status,
			'modifiedDate' => date('Y-m-s')
			);
	
			$inserdata = $this->mdl_gallery->updateGalleryName($galleryId,$data);
				if($inserdata == 1)
			{
				$this->session->set_flashdata('success', 'Gallery Name Updated Successfully!!!');
					echo 'success';	
			}	
			else
			{
				echo '"Oops. Something went wrong. Please try again later."';
			}		
		 }
	}  
	   
	  
	function addImage()	
	{
		$data['galleryName'] = 	$this->mdl_gallery->all_gallery_view();
		$data['viewFile']     = "addImage";
		$data['page']         = 'gallery';
		$data['menu']         = "addimage";
		$template             = 'admin';
		echo Modules::run('template/' . $template, $data);
	}  
	 
	function insertgalleries()
	{
		$ans = $this->input->post();
		 $this->form_validation->set_rules('gallerytitle','gallery title','required');
		$this->form_validation->set_rules('gallery','select gallery','required');
		$this->form_validation->set_rules('imageposition','Image position','required');
  
	   if($this->form_validation->run() == FALSE) 
		   {
			echo validation_errors();
		   } 
	   else
	     {
			$gallerytitle = $ans['gallerytitle'];
			$galleryname = $ans['gallery'];
			$imageposition = $ans['imageposition'];
			$img = $_FILES['img']['name'];
		 
			if(!empty($img))
			{
				$image = str_replace(" ","_",time().$img);
				$imgupload = $this->uploadFile($image,"img","gallery");
			} 
				$data = array(
		             'imgtitle'=>$gallerytitle,
					 'galId'=>$galleryname,
					 'imgposition'=>$imageposition,
					 'imgPath'=>$image,
					 'createdDate' => date('Y-m-s'),
					'modifiedDate' => date('Y-m-s')
					 );
					 
			$inserdata = $this->mdl_gallery->insertGalleryImage($data);
			echo $inserdata;
		 }
	}	
	
		
	function imageslists()	
	{
		$getName = $this->mdl_gallery->all_galleryimages_view();
		$data['getAllImages'] = $getName;
		$data['viewFile']     = "viewimage";
		$data['menu']         = "imageslist";
		$data['page']         = 'gallery';
		$template             = 'admin';
		echo Modules::run('template/' . $template, $data);
	}

		function edit_galleryimage($id)
	{
		$data['galleryName'] = 	$this->mdl_gallery->all_gallery_view();	
		$get_single_banner_record = $this->mdl_gallery->get_gallery_image_data($id);
		$data['singlegallerydata']     = $get_single_banner_record;
		$data['viewFile']         = "editimages";
		$data['page']             = "gallery";
		$data['menu']         = "imagesedit";
		$template                 = 'admin';
		echo Modules::run('template/' . $template, $data);
	}	
	 
		 	function updategalleryimage()
	{
		$formdata = $this->input->post();
		  $this->form_validation->set_rules('gallerytitle','gallery title','required');
		$this->form_validation->set_rules('gallery','select gallery','required');
		$this->form_validation->set_rules('imageposition','Image position','required');
	  
	   if($this->form_validation->run() == FALSE) 
		   {
			echo validation_errors();
		   } 
	   else
	     {
				  $id = $this->input->post('imageid');
				  $title = $this->input->post('gallerytitle');
				  $desc = $this->input->post('gallery');
				  $image = $_FILES['img']['name'];
				  $link = $this->input->post('imageposition');  
				  $himg = $this->input->post('imagename');
	 
			  if(empty($image))
				{
				 $image1 = $himg;			
				}
			   else
				 {
				 $image1 = str_replace(" ","_",time().$image);
				 $ans = $this->uploadFile($image1,"img","gallery");
				// unlink("uploads/stories/".$himg); 
				 }	
		 
			  $data= array(
					 'imgtitle'=>$title,
					 'galId'=>$desc,
					 'imgposition'=>$link,
					 'imgPath'=>$image1,
					'modifiedDate' => date('Y-m-s')
					);
			 $updatedata = $this->mdl_gallery->updategallery_content($id,$data);
			if($updatedata == 1)
			{
				$this->session->set_flashdata('success', 'Image Updated Successfully!!!');
					echo 'success';	
			}	
			else
			{
				echo '"Oops. Something went wrong. Please try again later."';
			}		
		 }	 
	}
	   
	function getAllDatas($id)
	{	
		return $this->mdl_gallery->getGalleryImages($id);
	}	
	

}
