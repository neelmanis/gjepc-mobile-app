<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mdl_gallery extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	function get_table() {
		$table = "stories";
		return $table;
	}

	/*------------------------------ INSERT BANNER FUNCTION -----------------------------------*/
	function insertStories($data)
	{		
		 $this->db->insert('stories',$data);
		return 1; 
	}
		function insertGalleryName($data)
	{		
		 $this->db->insert('galleryname',$data);
		return 1; 
	}
	function insertGalleryImage($data)
	{		
		 $this->db->insert('galleryimages',$data);
		return 1; 
	}
	
		function all_stories_view()
	{
		$this->db->select('stories.*,galleryname.name');
		$this->db->from('stories');
		$this->db->join('galleryname', 'stories.galleryname = galleryname.galleryId','left');
		$this->db->where('str_status', '1');
		$this->db->order_by('str_id', 'ASC');
		$storiesView = $this->db->get();	
		if($storiesView->num_rows > 0)
			$getStories = $storiesView->result();
		else
			$getStories = "no";

		return $getStories;
	}
	
	
	
	
	
		function all_gallery_view()
	{
		$this->db->where('isactive', '1');
		$this->db->order_by('galleryId', 'ASC');
		$galleryName = $this->db->get('galleryname');

		if($galleryName->num_rows > 0)
			$getName = $galleryName->result();
		else
			$getName = "no";

		return $getName;
	}
		function all_galleryimages_view()
	{
		$this->db->select('galleryimages.*,galleryname.name');
		$this->db->from('galleryimages');
		$this->db->join('galleryname', 'galleryimages.galId = galleryname.galleryId');
		$galleryImage = $this->db->get();

		if($galleryImage->num_rows > 0)
			$getName = $galleryImage->result();
		else
			$getName = "no";

		return $getName;
	}
	
	function stories_delete($id)
	{
		$this->db->where('str_id',$id);		
		$this->db->delete("stories");
		return 1;
	}
		function gallery_delete($id)
	{
		$this->db->where('galleryId',$id);		
		$this->db->delete("galleryname");
		return 1;
	}
	function galleryimage_delete($id)
	{
		$this->db->where('imgId',$id);		
		$this->db->delete("galleryimages");
		return 1;
	}
	
	function get_single_data($id)
	{
		$bannerSingle = $this->db->get_where("stories","str_id = $id");
		if($bannerSingle->num_rows > 0)
			$singleBanner = $bannerSingle->result();
		else
			$singleBanner = "no";

		return $singleBanner;
	}
		function get_gallery_single_data($id)
	{
		$bannerSingle = $this->db->get_where("galleryname","galleryId = $id");
		if($bannerSingle->num_rows > 0)
			$singleBanner = $bannerSingle->result();
		else
			$singleBanner = "no";

		return $singleBanner;
	}
	
		function get_gallery_image_data($id)
	{
		$bannerSingle = $this->db->get_where("galleryimages","imgId = $id");
		if($bannerSingle->num_rows > 0)
			$singleBanner = $bannerSingle->result();
		else
			$singleBanner = "no";

		return $singleBanner;
	}
	
	
	function  updateStories_content($id,$data)
	{
		$this->db->where('str_id',$id);		
		$this->db->update("stories",$data);
		return 1;
	}
	
	function  updategallery_content($id,$data)
	{
		$this->db->where('imgId',$id);		
		$this->db->update("galleryimages",$data);
		return 1;
	}
	
	function updateGalleryName($id,$data)
	{
		$this->db->where('galleryId',$id);		
		$this->db->update("galleryname",$data);
		return 1;
	}
		function getStoriesRecord($url)
	{
		$storiesdata = $this->db->get_where("stories","str_url = $url and str_status = '1'");
		if($storiesdata->num_rows > 0)
			$storiesDataRecords = $storiesdata->result();
		else
			$storiesDataRecords = "no";

		return $storiesDataRecords;
	}
	function getDefaultRecord($status)
	{
		if($status  == 1)
		{
			$default = $this->db->get_where("galleryname",array('isDefault' => $status));	
			$ans = $default->result();
			if(is_array($ans))
			{
				foreach($ans as $set)
				{
					$maindefault = $this->_update($set->galleryId);	
				}	
			}
		}		
	}
	
	function _update($set)
	{
		$this->db->where('galleryId',$set);		
		$this->db->update("galleryname",array('isDefault'=>'0'));
	}
}