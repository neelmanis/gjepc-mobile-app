<div class="form-panel">
    <h4 class="mb">Add Gallery</h4>
	<form class="form-horizontal style-form" method="post" id="galleryimage" enctype="multipart/form-data">
		<div class="form-group" id='message'>
			<div class="col-sm-12">
			</div>
		</div>
		<div class="form-group" id='error_span'>
			<div class="col-sm-12">
				<span class="help-inline"></span>
			</div>
		</div>

		<div class="form-group">
	       	<label class="col-sm-3 control-label" for="username">Gallery Title</label>
		    <div class="col-sm-9">
				<input type="text" name="gallerytitle" id="gallerytitle" class="form-control" />
			</div>
		</div>

		<div class="form-group">
		    <label class="col-sm-3 control-label">Select Gallery</label>
		    <div class="col-sm-9">
			    <select  name="gallery" id="gallery" class="form-control">
			    	<option value="">Choose One</option>
					<?php if($galleryName){ 
						foreach($galleryName as $names) {
					?>
			        <option value="<?php echo $names->galleryId;?>"><?php echo $names->name;?></option>
					<?php } } ?>
				</select>
		    </div>
		</div>                          

		<div class="form-group">
			<label class="col-sm-3 control-label">Gallery Image</label>
			<div class="col-sm-9">
				<input type="file" name="img" id="img" class="form-control"/>
				<div class='alert alert-warning'><b>Note!</b> Image should be in 392 X 253 size</div>
				<!-- <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a> -->
			</div>
		</div>
		
		
		<div class="form-group">
	       	<label class="col-sm-3 control-label" for="username">Image Position</label>
		    <div class="col-sm-9">
				<input type="text" name="imageposition" id="imageposition" class="form-control" />
			</div>
		</div>
	    <div class="form-group">
		    <label class="col-sm-3 control-label">Status</label>
		    <div class="col-sm-9">
			    <select  name="banner_status" id="banner_status" class="form-control">
			    	<option value="">Choose One</option>
			        <option value="1">Active</option>
			        <option value="0">Deactivate</option>
			    </select>
		    </div>
		</div>
		
		<div class="form-group">
			<label class="col-sm-3 control-label">&nbsp;</label>
			<div class="col-sm-9">
				<input type="submit" class="btn btn-primary" id="banner_btn" value='Save'>
			</div>
		</div>
	</form>
</div>	

	
<script>
var baseUrl = '<?php echo base_url() ?>';
(function($){
    $("#galleryimage").on("submit",function(e){ 
		e.preventDefault();
		if(window.FormData != 'undefined'){
			var formdata = new FormData(this);

			jQuery.ajax({
				type :"POST",
				data :formdata,
				url :baseUrl+"gallery/insertgalleries",
				processData : false,
				contentType : false,
				//mimeType : 'multipart/form-data',
				success : function(result){ 
				 if(result==1) {
						jQuery('input:not(".noreset")').val('');
						jQuery('div#message').find('div').html('<div class="alert alert-success">New Image added successfully !!!</div>');
					}
					else {
						jQuery('div#message').find('div').html('<div class="alert alert-danger">' + result + '</div>');
					}
					window.scrollTo(0,0); 
				}
			})
		} 
	});	
})(jQuery)	
</script>			
			