<?php if(is_array($singlegallerydata)) { 
/*  echo "<pre>";
print_r($singlegallerydata);
exit;  */
?>
<div class="form-panel">
    <h4 class="mb">Edit gallery Images</h4>	
	<form class="form-horizontal style-form" method="post" id="editgalleryimage" enctype="multipart/form-data">
			<div class="form-group" id='message'>
			<div class="col-sm-12">
			</div>
		</div>
			
		<div class="form-group" id='error_span'>
			<div class="col-sm-12">
				<span class="help-inline"></span>
			</div>
		</div>

		<div class="form-group">
	       	<label class="col-sm-3 control-label" for="username">Gallery Title</label>
		    <div class="col-sm-9">
				<input type="text" name="gallerytitle" id="gallerytitle" class="form-control" value="<?php echo $singlegallerydata[0]->imgtitle;?>" />
			</div>
		</div>

		<div class="form-group">
		    <label class="col-sm-3 control-label">Select Gallery</label>
		    <div class="col-sm-9">
			    <select  name="gallery" id="gallery" class="form-control">
			    	<option value="">Choose One</option>
					<?php if($galleryName){ 
						foreach($galleryName as $names) {
					?>
			        <option value="<?php echo $names->galleryId;?>" <?php if($singlegallerydata[0]->galId == $names->galleryId){ echo "selected"; }?>><?php echo $names->name;?></option>
					<?php } } ?>
				</select>
		    </div>
		</div>                          

		<div class="form-group">
			<label class="col-sm-3 control-label">Gallery Image</label>
			<div class="col-sm-9">
				<img src="<?php echo base_url();?>uploads/gallery/<?php echo $singlegallerydata[0]->imgPath;?>" style="width:100px !important;height:100px !important;">
				<input type="file" name="img" id="img" class="form-control"/>
				<div class='alert alert-warning'><b>Note!</b> Image should be in 392 X 253 size</div>
				<!-- <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a> -->
			</div>
		</div>
		
		
		<div class="form-group">
	       	<label class="col-sm-3 control-label" for="username">Image Position</label>
		    <div class="col-sm-9">
				<input type="text" name="imageposition" id="imageposition" class="form-control" value="<?php echo $singlegallerydata[0]->imgposition;?>"/>
			</div>
		</div>
		<input type="hidden" name="imageid" value="<?php echo $singlegallerydata[0]->imgId;?>">

		<input type="hidden" name="imagename" value="<?php echo $singlegallerydata[0]->imgPath;?>">
		<div class="form-group">
			<label class="col-sm-3 control-label">&nbsp;</label>
			<div class="col-sm-9">
				<input type="submit" class="btn btn-primary" id="banner_btn" value='Save'>
			</div>
		</div>
	</form>
</div>	
	
<script>
var baseUrl = '<?php echo base_url() ?>';
(function($){
    $("#editgalleryimage").on("submit",function(e){ 
		e.preventDefault();
		if(window.FormData != 'undefined'){
			var formdata = new FormData(this);

			jQuery.ajax({
				type :"POST",
				data :formdata,
				url :baseUrl+"gallery/updategalleryimage",
				processData : false,
				contentType : false,
				//mimeType : 'multipart/form-data',
				success : function(result){ 
				if(result=='success') {
							location.href = baseUrl + "gallery/imageslists";
					}
					else {
						jQuery('div#message').find('div').html('<div class="alert alert-danger">' + result + '</div>');
					}
					window.scrollTo(0,0);
				}
			})
		} 
	});	
})(jQuery)	
</script>			
			
<?php } ?>		