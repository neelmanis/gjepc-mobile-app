<div class="row mt">
    <div class="col-lg-12">
			<div class="alert alert-danger errorMsg hide alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			"<b>Oops. </b>Something went wrong. Please try again later."
		</div>
		<?php if(!empty($this->session->flashdata('success'))): ?>
		<div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<?php echo $this->session->flashdata('success'); ?>
		</div>
		<?php endif; ?>
        <div class="content-panel">
        	<h4>View Gallery Images</h4>
	        <section id="no-more-tables">
	            <table class="table table-striped table-condensed cf" id='bannerTable'>
	            <thead class="cf">
					<tr>
					  	<th>Title</th>
					  	<th>Position</th>
						<th>Image</th>
						<th>Gallery Name</th>
						<th><i class=" fa fa-edit"></i> Option</th>
					</tr>
				</thead>

				<tbody>
				<?php 
					if(is_array($getAllImages) && !empty($getAllImages)):
						foreach($getAllImages as $images_data):
				?>
					<tr>
					  	<td data-title="Title"><a href="#"><?php echo $images_data->imgtitle;?></a></td>
						<td data-title="Title"><a href="#"><?php echo $images_data->imgposition;?></a></td>
						<td data-title="Title"><a href="#"><?php echo $images_data->name;?></a></td>
						<td data-title="Big Image">
							<img src="<?php echo base_url();?>uploads/gallery/<?php echo $images_data->imgPath; ?>" width='100' height='100' style='margin-bottom:5px'>
							<br><a href='<?php echo $stories_data->str_img;?>'></a>
						</td>
						<td data-title="Actions">
							<button class="deleterows btn btn-danger btn-xs" data-id='<?php echo $images_data->imgId;?>' title='Delete Gallery Name' data-info="<?php echo $images_data->imgId;?>" data-target="#myModal" data-toggle="modal"><i class="fa fa-trash-o "></i></button>
							<!--<a class="deleterows btn btn-danger btn-xs" id='<?php echo $images_data->imgId;?>' title='Archive Banner'><i class="fa fa-trash-o "></i></a>-->
							<a class="btn btn-primary btn-xs" href='<?php echo base_url();?>gallery/edit_galleryimage/<?php echo $images_data->imgId;?>' title='Edit Gallery Name'><i class="fa fa-pencil"></i></a>
						</td>
					</tr>
				<?php
						endforeach;
					endif;
				?>
				</tbody>
	        </table>        	
        </div>
    </div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
			</div>
			<div class="modal-body">
				Are you sure, you want to <b>Delete?</b>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default modalClose" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-danger deleteConfirmed">Delete</button>
			</div>
		</div>
	</div>
</div>
<script>				
	jQuery(document).ready(function(){
		$('#bannerTable').DataTable({
			"order": [[ 1, "asc" ]]
		});
			jQuery('.deleterows').on('click', function(){
			$this = jQuery(this);
			var modal = $this.data('target');
			jQuery(modal)
			.find('.modal-body span').text($this.data('info')).end()
			.find('.modal-footer button.btn-danger').attr('id', $this.data('id'));
		})
		
		jQuery(".deleteConfirmed").on("click",function(e){
			e.preventDefault();
			var banner_id = this.id;
		jQuery.ajax({
				type:"POST",
				url:"<?php echo base_url();?>gallery/delete_galleryimagename",
				data:{Banner_id:banner_id},
				success:function(result){
						if(result == 'success'){
					$this.siblings('button').trigger('click');
					jQuery('.errorMsg').addClass('hide');
					location.reload(true);
					}
					else{
					$this.siblings('button').trigger('click');
					jQuery('.errorMsg').removeClass('hide');
					}
				}
			}) 
		});
	});			
</script>				