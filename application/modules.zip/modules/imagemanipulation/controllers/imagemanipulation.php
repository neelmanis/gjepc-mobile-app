<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Imagemanipulation extends MX_Controller
{

}