<?php 
$thumbUrl = (!empty($profile->profilePhoto)) ? base_url("uploads/$profile->regId/profile/$profile->profilePhoto") : '';
$allProjects = Modules::run('projects/getAllActiveProjects', $regId);

?>
<script src='<?php echo base_url()?>assets/js/jquery.onImagesLoad.min.js'></script>
<script type='text/javascript' src="<?php echo base_url('assets/js/jquery.imgareaselect.pack.js')?>"></script>

<div id="fade" class="well">
  <header>Your Profile Photo</header>
  <div class="body upload-wrapper">
    <p>Drag the corner of the box to change position and size, or upload a new image.</p>
    <div class="row">
      <div class="col-sm-6">
        <div class="content">
          <div class="preview" id="preview">
          <div class='loader absolute_loader' style='display: none;'></div>
          <img <?php echo ($thumbUrl!='') ? "src='$thumbUrl'": '' ?> id='selectArea'>
					<input type='hidden' id='imageName' name='imgName' value='<?php echo $profile->profilePhoto ?>'>

	    		</div>
        </div>
        <div class="controls">
					<button class='rotate' data-rotation='90'><i class="fa fa-2x fa-undo"></i></button>
					<button class='rotate' data-rotation='270'><i class="fa fa-2x fa-repeat"></i></button>
					<!-- <button><i class="fa fa-2x fa-trash"></i></button> -->

				</div>
    
      </div>
      <div class="col-sm-6">
        <div class="content">
          
          <?php echo form_open_multipart('imagemanipulation/upload', array('id' => 'userfile','class'=>'fileUpload')); ?>
            <input type='file' name='userfile' id='fileUploader' class='upload'>
					  <input type="hidden" name="x1" value="" />
	  				<input type="hidden" name="y1" value="" />
	  				<input type="hidden" name="x2" value="" />
	  				<input type="hidden" name="y2" value="" />
					<span>Click or Drag &amp; Drop Files here to upload</span>
				<?php echo form_close(); ?>
        </div>
        <p><em>You can upload a JPG, GIF or PNG file</em></p>
      </div>
      <p class="error"></p>
    </div>
  </div>
  <footer class="text-right"> <a class="btn whitebutton fade_close">Cancel</a>
    <button class="btn" id="crop">Save</button>
  </footer>
</div>

<div id="cover" class="well coverPopup">
    <header>Choose Cover Photo</header>
    <div class="body upload-wrapper twoColumn">
        <p>We’re only showing you photos that are wide enough to go across the entire width of your profile</p>
        <div class="row">
            <div class="col-sm-6">
                <div class="content noBorder">
                    <div class="form-group">
                        <select class="form-control" id='changecover' >
                            <option value="<?php echo rtrim(base64_encode('DecoramaCover'),'=') ?>">Decorama Gallery</option>
                            <?php foreach ($allProjects as $key => $value) { 
                                if($value == DEFAULT_PROJ)
                                  continue;

                                $encodeString = $key.'_'.$regId
                            ?>
                            <option value='<?php echo rtrim(base64_encode($encodeString), "="); ?>'><?php echo $value; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="galleryView"></div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="content">
                    <div class="selectedImg">
                        <div>
                            <div class='loader absolute_loader' style='display: none;'></div>
                            <a class="close"></a>
                            <span><img src=""></span>
                        </div>
                    </div>
                    <form action="#" class="fileUpload" id='coverForm'>
                        <input type='file' name='userfile' id='coverfileUploader' class='upload'>
                        <span>Click or Drag &amp; Drop File here to upload</span>
    		            </form>
                </div>
            </div>
        </div>
    </div>
    <div class="body upload-wrapper oneColumn">
        <p>Drag and resize the crop area to edit the cover image.</p>
        <div class="row">   
            <div class="col-sm-12">
                <div class="content">
                    <div class="coverPreview">
                        <img src="" id='coverImagePreview'>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-right"> <a class="btn whitebutton cover_close">Cancel</a>
        <button class="btn useBtn" disabled>Use Photo</button>
        <button class="btn saveBtn">Save</button>
    </footer>
</div>
<?php if($edit) :?>
<script type='text/javascript'>var baseUrl = '<?php echo base_url(); ?>'</script>
<script type="text/javascript" src='<?php echo base_url()?>assets/js/profile/showModal.js'></script>
<script type="text/javascript" src='<?php echo base_url()?>assets/js/profile/uploadify.js'></script>
<script type="text/javascript" src='<?php echo base_url()?>assets/js/profile/coverphoto.js'></script>
<?php endif; ?>