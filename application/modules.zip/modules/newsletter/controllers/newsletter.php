<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Newsletter extends MX_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('mdl_newsletter');
		$this->load->library('form_validation');
	}
	/******************************************* Newsletter VIEW FILE ***********************************************/
	function newsletters()
	{
		$this->load->view('newsletters');
	}
	/*****************************************************************************************************************/
	/**********************************************Newsletter Submit ACtion*******************************************/
	function submit_newsletter()
	{
		$this->form_validation->set_rules('email','Email ID','xss_clean|trim|required|valid_email|max_length[100]|is_unique[newsletter.email]');
		if ($this->form_validation->run($this) == FALSE)
			echo validation_errors('<li>','</li>');
		else
		{
			$email = $this->input->post('email');
			$data = array(
			'email' => $email,
			'createdDate' => date('Y-m-d'),
			'modifiedDate' => date('Y-m-d'),
			);			
			
			$insertNewaletter  =  $this->mdl_newsletter->_insert($data);
			echo $insertNewaletter;
		}				
	}
	/************************************************************************************************************/
	/*****************************************************************************************/
	
	
	
	function get_where_custom($col, $value) {
		$query = $this->mdl_newsletter->get_where_custom($col, $value);
		return $query;
	}
	function customAlpha($str) 
	{
	  
        if ( !preg_match('/^[a-z .,\-]+$/i',$str) )
        {
            return false;
        }
    
	}
	
	
	function listall()
	{
		$allsubscribers = $this->mdl_newsletter->get_all_newsletter();
		if(is_array($allsubscribers))
		{
			$data['newsletters'] = $allsubscribers;	
		}	
		$data['viewFile'] = "listnewsletter";
		$data['page'] = 'newsletter';
		$template = 'admin';
		echo Modules::run('template/'.$template, $data);
	}
	
	function delete($id)
	{
		$newsid = $id;
		if(intval($newsid)) {
			$deletesubscriber = $this->mdl_newsletter->deletesubscribe($newsid);
			if($deletesubscriber)
				echo "success";
			else
				echo '"Oops. Something went wrong. Please try again later."';
		}
		else
			echo '"Oops. Something went wrong. Please try again later."'; 
	}
	
		function lists($status = 'active')
	{
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'newsletter';
		$data['menu'] = 'lists';
		
		$isActive = ($status == 'active') ? '1' : '0';
		$data['statusemail'] = $isActive; 
		$getCms = $this->mdl_newsletter->getAllNewsletters(array('isActive'=>$isActive));
		$data['getAllCms'] = $getCms;
		echo Modules::run('template/'.$template, $data);
	}
	
	function unsubscribe($id,$action)
	{
		if(Modules::run('site_security/is_admin')):
			if(empty($id)) {
				show_error(INVALID_PAGE);
			}
			else {
				 $result = $this->mdl_newsletter->unsubscribeemail($id,$action);
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success')
					echo 'success';
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}
	
}



/* End of file welcome.php */

/* Location: ./application/controllers/welcome.php */