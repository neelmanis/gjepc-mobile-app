<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mdl_newsletter extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	function get_table() {
		$table = "newsletter";
		return $table;
	}
		
	function _insert($data) {
		$table = $this->get_table();
		return $this->db->insert($table, $data);
	}
	function _insertId(){
		return $this->db->insert_id();
	}
	function get_where_custom($col, $value) {

		$table = $this->get_table();
		$this->db->where($col, $value);
		$query=$this->db->get($table);
		return $query;
	}
	
	function get_all_newsletter()
	{
		$table = $this->get_table();	
		$news = $this->db->get_where($table,array('isActive' => '1'));
		if($news->num_rows > 0)
		{
			return $news->result();	
		}	
		else
		{
			return "no";
		}	
	}
	
	function deletenews($id)
	{
		$table = $this->get_table();	
		$this->db->where('id', $id);
		return $this->db->delete($table);
	}
	
	function deletesubscribe($id)
	{
		$table = $this->get_table();	
		$this->db->where('id', $id);
		return $this->db->delete($table);
	}
	
	
	function unsubscribeemail($id,$action)
	{
		if($action == 1)
			$status = '0';
		else
			$status = '1';
		$this->db->where('id', $id);
		$this->db->update('newsletter', array('isActive' => $status )); 
		echo "success";
	}
	
	
	function getAllNewsletters($filters = array())
	{
		$table = $this->get_table();

		if(sizeof($filters)){
			foreach($filters as $key=>$value)
				$this->db->where($key, $value);

			$query = $this->db->get($table);
			return $query->result();
		}
		else
			return FALSE;
	}
}