<div class="row mt">
    <div class="col-lg-12">
    	
        <div class="content-panel">
        	
	        <section id="no-more-tables">
	            <table class="table table-striped table-condensed cf" id='subscriberTable'>
	            <thead class="cf">
					<tr>
					  	<th>Sr. No.</th>
					  	<th>Name</th>
						<th>Email</th>	
					  	<th>Status</th>
						<th><i class=" fa fa-edit"></i> Option</th>
					</tr>
				</thead>

				<tbody>
				<?php $i=1; foreach($newsletters as $newsletter):?> 
					<tr>
					  	<td data-title="Sr. No."><a href="#"><?php echo $i;?></a></td>
						<td data-title="Name"><?php echo $newsletter->name;?></td>
						<td data-title="Email"><?php echo $newsletter->email;?></td>			
						<td data-title="Status"><?php echo ($newsletter->isActive == '1') ? 'Active':'Archived'; ?></td>
						<td data-title="Actions">
							<button class="deleterows btn btn-danger btn-xs" data-id='<?php echo $newsletter->id;?>' title='Delete newsletter' data-info="<?php echo $newsletter->name;?>" data-target="#myModal" data-toggle="modal"><i class="fa fa-trash-o "></i></button>
						</td>
					</tr>
				<?php $i++; endforeach; ?>
				</tbody>
	        </table>        	
        </div>
    </div>
</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Delete Confirmation</h4>
			</div>
			<div class="modal-body">
				Are you sure, you want to <b>Delete?</b>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default modalClose" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-danger deleteConfirmed">Delete</button>
			</div>
		</div>
	</div>
</div>

<script>				
	jQuery(document).ready(function(){
		var t = $('#subscriberTable').DataTable({
			"order": [[ 2, "asc" ]],
			"columnDefs": [
	            {
	                "targets": [ 3 ],
	                "visible": false,
	                "searchable": false,
	            },
	            {
	                "targets": [ 0 ],
	                "searchable": false,
	                "orderable":false
	            },
	            {
	                "targets": [ 4 ],
	                "searchable": false,
	                "orderable":false
	            },
	            
	        ]
		});

		t.on( 'order.dt search.dt', function () {
	        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
	            cell.innerHTML = i+1;
	        } );
	    } ).draw();
		
		jQuery('.deleterows').on('click', function(){
			$this = jQuery(this);
			var modal = $this.data('target');
			jQuery(modal)
			.find('.modal-body span').text($this.data('info')).end()
			.find('.modal-footer button.btn-danger').attr('id', $this.data('id'));
		})

		jQuery(".deleteConfirmed").on("click",function(){
			var subscriberId = this.id;
			var $this = jQuery(this);
			
			jQuery.ajax({
				type:"POST",
				data:{subscriberId: subscriberId},
				url:"<?php echo base_url();?>newsletter/deletenews",
				success:function(result){
					//alert(result);
					 if(result == 'success'){
						//$this.siblings('.modalClose').trigger('click');
						location.reload(true);
					} 
				}
			}) 
		});

		if(jQuery('div.alert-dismissable').length){
			jQuery('div.alert-dismissable').delay(5000).fadeOut(500);
		}
	});			
</script>				