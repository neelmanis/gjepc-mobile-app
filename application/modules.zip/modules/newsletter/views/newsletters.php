<div class="container-fluid newsletter">
  <div class="container">
    <form class="row form-inline" id="newsletter">
      <label>Newsletter</label>
      <p class="help-block">Sign Up Today!</p>
      <div class="form-group">
        <input class="form-control" type="text" name="email" placeholder="Enter Your Email">
      </div>
      <input class="btn" type="submit">
    </form>
  </div>
</div>