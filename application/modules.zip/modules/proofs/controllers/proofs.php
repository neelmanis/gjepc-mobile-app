<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Proofs extends MX_Controller
{
	function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_proofs');

	}

	function _getName($govId = 0){
		$result = $this->mdl_proofs->get_where(array('govId'=>$govId));
		return $result[0]->name;
	}

	function collection($id = 0){
		if(isset($_POST['isAjax'])) {
			$id = intval($id);
			$result = $this->mdl_proofs->get_where(array('govId !=' => $id, 'isActive'=> '1'));
			echo json_encode($result);
		}
		else{
			redirect('/');
		}
	}
	
	function lists($status = 'active')
	{
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'masters';
		$data['menu'] = 'government';

		$isActive = ($status == 'active') ? '1' : '0';

		$getproofs = $this->mdl_proofs->get_where(array('isActive'=>$isActive));
		$data['getproofs'] = $getproofs;
		echo Modules::run('template/'.$template, $data);
	}

	function add(){
		$template = 'admin';
		$data['viewFile'] = "add";
		$data['page'] = 'masters';
		$data['menu'] = 'government';

		echo Modules::run('template/'.$template, $data);
	}

	function edit($govId){
		$template = 'admin';
		$data['viewFile'] = "edit";
		$data['page'] = 'masters';
		$data['menu'] = 'government';
		$govId = intval($govId);

		$getProofs = $this->mdl_proofs->get_where(array('govId'=>$govId));
		$data['proof'] = $getProofs[0];
		$data['status'] = $getProofs[0]->isActive;
		echo Modules::run('template/'.$template, $data);
	}

	function newproof(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_proofs->newproof();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success')
					echo 'success';
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function editproof(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_proofs->editproof();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success') {
					$this->session->set_flashdata('success', 'Proof Updated Successfully!!!');
					echo 'success';
				}
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function delproof($govId){
		if(Modules::run('site_security/is_admin')):
			$govId = intval($govId);
			if($this->mdl_proofs->_delete($govId))
				echo 'success';
			else
				echo 'failure';
		else:
			show_error(INVALID_PAGE);
		endif;
	}
}

