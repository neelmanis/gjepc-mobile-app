<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mdl_proofs extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	function get_table() {
		$table = "govermentmaster";
		return $table;
	}

	function _insert($data) {
		$table = $this->get_table();
		return $this->db->insert($table, $data);
	}

	function _update($govId, $data) {
		$table = $this->get_table();
		$this->db->where('govId', $govId);
		return $this->db->update($table, $data);
	}

	function _delete($govId) {
		$table = $this->get_table();
		$this->db->where('govId', $govId);
		return $this->db->delete($table);
	}

	function get_where($filters = array()) {
		$table = $this->get_table();

		if(sizeof($filters)){
			$this->db->where($filters);

			$query = $this->db->get($table);
			return $query->result();
		}
		else
			return FALSE;
	}

	function _conditions($and = array(), $or = array()){
		$table = $this->get_table();
		$andconditon = FALSE; $orcondition = FALSE;

		if(sizeof($and)){
			$andconditon = TRUE;
			foreach($and as $key=>$value)
				$this->db->where($key, $value);
		}

		if(sizeof($or)){
			$orcondition = TRUE;
			foreach($or as $key=>$value)
				$this->db->or_where($key, $value);
		}

		if($orcondition || $andconditon){
			$query = $this->db->get($table);
			return $query->result();
		}

		return FALSE;
	}

	function newproof(){

		$this->form_validation->set_rules('govIdName','Name','trim|required|max_length[100]|xss_clean');
		$this->form_validation->set_rules('isActive','Status','trim|required|is_natural|xss_clean');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');

		if(!$this->form_validation->run())
			return 'validationErrors';
		else{
			$_POST['createdDate'] = date('Y-m-d h:i:s');
			$_POST['modifiedDate'] = date('Y-m-d h:i:s');

			if($this->_insert($this->input->post())):
				return 'success';
			else:
				return 'failed';
			endif;
		}
	}

	function editproof(){

		$this->form_validation->set_rules('govId','Category','trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('govIdName','Name','trim|required|max_length[100]|xss_clean');
		$this->form_validation->set_rules('isActive','Status','trim|required|is_natural|xss_clean');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');
		$this->form_validation->set_message('numeric', '%s Invalid');

		if(!$this->form_validation->run())
			return 'validationErrors';
		else{
			$_POST['modifiedDate'] = date('Y-m-d h:i:s');
			$govId = $this->input->post('govId');

			if($this->_update($govId, $this->input->post())):
				return 'success';
			else:
				return 'failed';
			endif;
		}
	}
}