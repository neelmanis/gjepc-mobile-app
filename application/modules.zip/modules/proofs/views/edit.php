<div class="form-panel">
	<h4 class="mb">Edit Goverment Id</h4>
	<form id="form" class="form-horizontal style-form" action="<?php echo base_url()?>proofs/editproof">
		<input type="hidden" name="govId" value="<?php echo $proof->govId; ?>" />
		<span id="pagestatus"><?php echo $status; ?></span>
		<div class="form-group" id='message'>
			<div class="col-sm-12">
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label" for="username">Name</label>
			<div class="col-sm-9">
				<input type="text" name="govIdName" class="form-control" value="<?php echo $proof->govIdName; ?>" />
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label">Status</label>
			<div class="col-sm-9">
				<select  name="isActive" class="form-control">
					<option value="">Choose One</option>
					<option value="1" <?php echo ($proof->isActive == 1) ? 'selected':'' ?>>Active</option>
					<option value="0" <?php echo ($proof->isActive == 0) ? 'selected':'' ?>>Deactivate</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label">&nbsp;</label>
			<div class="col-sm-9">
				<input type="submit" class="btn btn-primary noreset" value='Save'>
			</div>
		</div>
	</form>
</div>

<script>
	(function($){

		jQuery('#form').on('submit',function(e) {
			e.preventDefault();

			var formObj = jQuery(this);
			var formUrl = formObj.attr('action');
			var data = formObj.serialize();

			jQuery.ajax({
				url: formUrl,
				type: 'POST',
				data: data,
				beforeSend: function (xhr, opts) {

				},
				success: function (data, textStatus, jqXHR) {
					if (data == 'success') {
						var statusVal = parseInt(jQuery('#pagestatus').text());
						var redirectTo = (statusVal) ? 'active':'inactive';
						location.href = baseUrl + "proofs/lists/" + redirectTo;
					}
					else {
						jQuery('div#message').find('div').html('<div class="alert alert-danger">' + data + '</div>');
					}
					window.scrollTo(0, 0);
				},
				error: function (jqXHR, textStatus, errorThrown) {
					console.log(errorThrown);
				}
			});
		});
	})(jQuery)
</script>