<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class States extends MX_Controller
{
	function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_states');

	}

	function _getName($stateId = 0){
		$result = $this->mdl_states->get_where(array('stateId'=>$stateId));
		return $result[0]->name;
	}

	function jsonstate($countryId = 0){
		$new = array(); $json = array();
		$countryId = intval($countryId);
		$states = $this->mdl_states->_conditions(array('isActive'=>'1', 'country_id'=>$countryId));

		foreach($states as $state){
			$new['id'] = $state->stateId;
			$new['text'] = $state->name;

			array_push($json, $new);
		}
		echo json_encode($json);
	}

	function collection($id = 0){
		if(isset($_POST['isAjax'])) {
			$id = intval($id);
			$country_id = intval($_POST['country_id']);
			$result = $this->mdl_states->get_where(array('stateId !=' => $id, 'country_id'=>$country_id, 'isActive'=> '1'));
			echo json_encode($result);
		}
		else{
			redirect('/');
		}
	}

	function lists($status = 'active')
	{
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'masters';
		$data['menu'] = 'state';

		$isActive = ($status == 'active') ? '1' : '0';

		$getstates = $this->mdl_states->get_where(array('isActive'=>$isActive));
		$data['getstates'] = $getstates;
		echo Modules::run('template/'.$template, $data);
	}

	function add(){
		$template = 'admin';
		$data['viewFile'] = "add";
		$data['page'] = 'masters';
		$data['menu'] = 'state';

		echo Modules::run('template/'.$template, $data);
	}

	function edit($stateId){
		$template = 'admin';
		$data['viewFile'] = "edit";
		$data['page'] = 'masters';
		$data['menu'] = 'state';
		$stateId = intval($stateId);

		$getstates = $this->mdl_states->get_where(array('stateId'=>$stateId));
		$data['states'] = $getstates[0];
		$data['status'] = $getstates[0]->isActive;
		echo Modules::run('template/'.$template, $data);
	}

	function newstate(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_states->newstate();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success')
					echo 'success';
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function editstate(){
		if(Modules::run('site_security/is_admin')):
			if(!isset($_POST)) {
				show_error(INVALID_PAGE);
			}
			else{
				$result = $this->mdl_states->editstate();
				if( $result == 'validationErrors')
					echo validation_errors('<p>','</p>');
				elseif( $result == 'failed')
					echo '"Oops. Something went wrong. Please try again later."';
				elseif( $result == 'success') {
					$this->session->set_flashdata('success', 'State Updated Successfully!!!');
					echo 'success';
				}
				else
					echo $result;
			}
		else:
			show_error(INVALID_PAGE);
		endif;
	}

	function delstate($stateId){
		if(Modules::run('site_security/is_admin')):
			$stateId = intval($stateId);
			if($this->mdl_states->_delete($stateId))
				echo 'success';
			else
				echo 'failure';
		else:
			show_error(INVALID_PAGE);
		endif;
	}
}

