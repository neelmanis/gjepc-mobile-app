<div class="form-panel">
    <h4 class="mb">Add State</h4>
	<form id="form" class="form-horizontal style-form" action="<?php echo base_url()?>states/newstate">
		<div class="form-group" id='message'>
			<div class="col-sm-12">
			</div>
		</div>

		<div class="form-group">
	       	<label class="col-sm-3 control-label" for="Name">State Name</label>
		    <div class="col-sm-9">
				<input type="text" name="name" class="form-control" />
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label" for="Country">Country</label>
			<div class="col-sm-9">
				<input type="text" name="country_id" id="countryId" class="form-control noreset" />
			</div>
		</div>

		<div class="form-group">
		    <label class="col-sm-3 control-label">Status</label>
		    <div class="col-sm-9">
			    <select  name="isActive" class="form-control">
			    	<option value="">Choose One</option>
			        <option value="1" selected >Active</option>
			        <option value="0">Deactivate</option>
			    </select>
		    </div>
		</div>
		
		<div class="form-group">
			<label class="col-sm-3 control-label">&nbsp;</label>
			<div class="col-sm-9">
				<input type="submit" class="btn btn-primary noreset" value='Save'>
				<a href="<?php echo base_url("states/lists")?>" class="btn btn-primary">Cancel</a>
			</div>
		</div>
	</form>
</div>			
<script>
(function($){

	function fillcountry(){
		$.ajax({
			url: baseUrl+'countries/jsoncountry',
			dataType:'JSON',
			success: function(data, textStatus, jqXHR){
				$('#countryId').select2({data: data, placeholder: 'Select Country'});
				$('#countryId').select2("val", '99');
			}
		})
	}

	window.onload = function(){ fillcountry() };

	jQuery('#form').on('submit',function(e) {
		e.preventDefault();

		var formObj = jQuery(this);
		var formUrl = formObj.attr('action');
		var data = formObj.serialize();

		jQuery.ajax({
			url: formUrl,
			type: 'POST',
			data: data,
			beforeSend: function (xhr, opts) {

			},
			success: function (data, textStatus, jqXHR) {
				if (data == 'success') {
					jQuery('input:not(".noreset")').val('');
					jQuery('div#message').find('div').html('<div class="alert alert-success">State has been added successfully !!!</div>');
				}
				else {
					jQuery('div#message').find('div').html('<div class="alert alert-danger">' + data + '</div>');
				}
				window.scrollTo(0, 0);
			},
			error: function (jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
			}
		});
	});
})(jQuery)	
</script>			
			