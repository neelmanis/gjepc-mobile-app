<div class="form-panel">
	<h4 class="mb">Edit State</h4>
	<form id="form" class="form-horizontal style-form" action="<?php echo base_url()?>states/editstate">
		<input type="hidden" name="stateId" value="<?php echo $states->stateId; ?>" />
		<span id="pagestatus"><?php echo $status; ?></span>
		<div class="form-group" id='message'>
			<div class="col-sm-12">
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label" for="Name">State Name</label>
			<div class="col-sm-9">
				<input type="text" name="name" class="form-control" value="<?php echo $states->name; ?>" />
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label" for="Country">Country</label>
			<div class="col-sm-9">
				<input type="text" name="country_id" id='countryId' class="form-control noreset" value="" />
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label">Status</label>
			<div class="col-sm-9">
				<select  name="isActive" class="form-control">
					<option value="">Choose One</option>
					<option value="1" <?php echo ($states->isActive == 1) ? 'selected':'' ?>>Active</option>
					<option value="0" <?php echo ($states->isActive == 0) ? 'selected':'' ?>>Deactivate</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<label class="col-sm-3 control-label">&nbsp;</label>
			<div class="col-sm-9">
				<input type="submit" class="btn btn-primary noreset" value='Save'>
			</div>
		</div>
	</form>
</div>

<script>
	(function($){

		function fillcountry(){
			var countryId = '<?php echo $states->country_id; ?>';
			$.ajax({
				url: baseUrl+'countries/jsoncountry',
				dataType:'JSON',
				success: function(data, textStatus, jqXHR){
					$('#countryId').select2({data: data, placeholder: 'Select Country'});
					$('#countryId').select2("val", countryId);
				}
			})
		}

		window.onload = function(){ fillcountry() };

		jQuery('#form').on('submit',function(e) {
			e.preventDefault();

			var formObj = jQuery(this);
			var formUrl = formObj.attr('action');
			var data = formObj.serialize();

			jQuery.ajax({
				url: formUrl,
				type: 'POST',
				data: data,
				beforeSend: function (xhr, opts) {

				},
				success: function (data, textStatus, jqXHR) {
					if (data == 'success') {
						var statusVal = parseInt(jQuery('#pagestatus').text());
						var redirectTo = (statusVal) ? 'active':'inactive';
						location.href = baseUrl + "states/lists/" + redirectTo;
					}
					else {
						jQuery('div#message').find('div').html('<div class="alert alert-danger">' + data + '</div>');
					}
					window.scrollTo(0, 0);
				},
				error: function (jqXHR, textStatus, errorThrown) {
					console.log(errorThrown);
				}
			});
		});
	})(jQuery)
</script>