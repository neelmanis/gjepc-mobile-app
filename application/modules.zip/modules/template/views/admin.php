<?php $adminData = $this->session->userdata('adminData'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <title>EasyRentil-Admin</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>admin_assets/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>admin_assets/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>admin_assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>admin_assets/css/style-responsive.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>admin_assets/css/table-responsive.css">
    <link href="<?php echo  base_url();?>admin_assets/css/select2-bootstrap.css" rel='stylesheet'/>
    <link href="<?php echo  base_url();?>admin_assets/css/select2.css" rel='stylesheet'/>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="<?php echo base_url(); ?>admin_assets/js/jquery.js"></script>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>admin_assets/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>admin_assets/resources/syntax/shCore.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>admin_assets/css/tree/style.css">


    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>admin_assets/js/jquery.dataTables.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>admin_assets/resources/syntax/shCore.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>admin_assets/resources/demo.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>admin_assets/js/bootstrap-treeview.js"></script>
    <script src="<?php echo  base_url();?>admin_assets/js/select2.min.js" ></script>
    <script> var baseUrl = '<?php echo base_url()?>'</script>
</head>
<body>
    <section id="container" >
        <!--header start-->
        <header class="header black-bg">
             <div class="sidebar-toggle-box">
                 <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
             </div>
            <!--logo start-->
            <a href="<?php echo base_url(); ?>dashboard/home" class="logo"><b>EASYRENTIL</b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">
                    <!-- settings start -->
                    <!-- inbox dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><?php echo anchor('admin/logout', 'Log Out',array('class'=>'logout')); ?></li>
                </ul>
            </div>
        </header>
        <!--header end-->

        <!--sidebar start-->
        <aside>
            <div id="sidebar"  class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered">
                        <a href="<?php echo base_url(); ?>dashboard/home"><img src="<?php echo base_url(); ?>admin_assets/images/user.jpg" class="img-circle" width="60"></a>
                    </p>
                    <h5 class="centered"><?php echo $adminData['userName'];?></h5>
                    <li class="mt">
                        <a <?php if($page=="dashboard"){?>class="active" <?php }?> href="<?php echo base_url();?>dashboard/home">
                            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                        </a>
                    </li>

                    <!-- Masters -->
                    <li class="sub-menu">
                        <a <?php if($page=="masters")echo "class='active'";?> href="javascript:;" >
                            <i class="fa fa-book"></i><span>Masters</span></a>
                        <ul class="sub">
                            <li <?php if($menu=="government"){?>class="active" <?php }?>><?php echo anchor('proofs/lists', 'Government Ids'); ?></li>
                            <li <?php if($menu=="country"){?>class="active" <?php }?>><?php echo anchor('countries/lists', 'Countries'); ?></li>
                            <li <?php if($menu=="state"){?>class="active" <?php }?>><?php echo anchor('states/lists', 'States'); ?></li>
                            <li <?php if($menu=="city"){?>class="active" <?php }?>><?php echo anchor('cities/lists', 'Cities'); ?></li>
                        </ul>
                    </li>
                    <!-- Masters menu end -->

                    <!-- Category menu -->
                    <li class="sub-menu">
                        <a <?php if($page=="categories")echo "class='active'";?> href="javascript:;" >
                            <i class="fa fa-cubes"></i><span>Categories</span></a>
                        <ul class="sub">
                            <li <?php if($menu=="lists"){?>class="active" <?php }?>><?php echo anchor('category/lists', 'List All'); ?></li>
                            <li <?php if($menu=="add"){?>class="active" <?php }?>><?php echo anchor('category/add', 'Add New'); ?></li>
                        </ul>
                    </li>
                    <!-- Category menu end -->

                    <!-- Users menu -->
                    <li class="sub-menu">
                        <a <?php if($page=="users")echo "class='active'";?> href="javascript:;" >
                            <i class="fa fa-user"></i><span>Users</span></a>
                        <ul class="sub">
                            <li <?php if($menu=="lists"){?>class="active" <?php }?>><?php echo anchor('users/lists', 'List All'); ?></li>
                        </ul>
                    </li>
                    <!-- Users menu end -->

                    <!-- Cms menu -->
                    <li class="sub-menu">
                        <a <?php if($page=="cms")echo "class='active'";?> href="javascript:;" >
                            <i class="fa fa-pencil-square-o"></i><span>Cms</span></a>
                        <ul class="sub">
                            <li <?php if($menu=="lists"){?>class="active" <?php }?>><?php echo anchor('cms/lists', 'List All'); ?></li>
                            <li <?php if($menu=="add"){?>class="active" <?php }?>><?php echo anchor('cms/add', 'Add New'); ?></li>
                        </ul>
                    </li>
					
					<!-- gallery menu -->
                    <li class="sub-menu">
                        <a <?php if($page=="gallery")echo "class='active'";?> href="javascript:;" >
                            <i class="fa fa-photo"></i><span>Gallery</span></a>
							<ul class="sub">
                            <li <?php if($menu=="lists"){?>class="active" <?php }?>><?php echo anchor('gallery/gallerylists', 'List All Gallery'); ?></li>
                            <li <?php if($menu=="add"){?>class="active" <?php }?>><?php echo anchor('gallery/addgallery', 'Add New Gallery'); ?></li>
							 <li <?php if($menu=="addimage"){?>class="active" <?php }?>><?php echo anchor('gallery/addImage', 'Add New Images'); ?></li>
                            <li <?php if($menu=="imageslist"){?>class="active" <?php }?>><?php echo anchor('gallery/imageslists', 'View Images'); ?></li>
							</ul>
                    </li>
					 <!-- Newsletters menu -->

                    <li class="sub-menu">
                        <a <?php if($page=="newsletter")echo "class='active'";?> href="javascript:;" >
                            <i class="fa fa-file-text"></i><span>Newsletters </span></a>
                        <ul class="sub">
                            <li <?php if($menu=="lists"){?>class="active" <?php }?>><?php echo anchor('newsletter/lists', 'List All'); ?></li>
                        </ul>
                    </li>
					
					
                </ul>
              <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->

        <!--main content start-->
        <section id="main-content">
            <section class="wrapper site-min-height">
                <div class="row mt">
                    <div class="col-lg-12">
                    <?php
                    if(!isset($module)){
                        $module = $this->uri->segment(1);
                    }

                    if(!isset($viewFile)){
                        $viewFile = $this->uri->segment(2);
                    }

                    if( $module != '' && $viewFile != '' ){
                        $path = $module. '/' . $viewFile;
                        echo $this->load->view($path);
                    }
                    ?>
                    </div>
                </div>
            </section>
        </section>
        <!--main content end-->

        <!--footer start-->
        <footer class="site-footer">
            <div class="text-center">2015 - EasyRentil</div>
        </footer>
        <!--footer end-->
    </section>

    <script src="<?php echo base_url(); ?>admin_assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo base_url(); ?>admin_assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url(); ?>admin_assets/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url(); ?>admin_assets/js/jquery.nicescroll.js" type="text/javascript"></script>

    <script src="<?php echo base_url(); ?>admin_assets/js/common-scripts.js"></script>
</body>
</html>
