<?php echo Modules::run('newsletter/newsletters');?>
<footer class="container">
    <div class="row">
        <div class="col-xs-6 col-md-3">
            <h6>About Us</h6>
            <div class="logo"><a href="<?php echo base_url() ?>"><img src="<?php echo base_url() ?>assets/images/logo.png"></a></div>
            <p><a href="mailto:support@easyrental.com"><i class="fa fa-envelope-o"></i> support@easyrental.com</a><a href="tel:02224981021"><i class="fa fa-phone"></i> 022 24981021</a></p>
        </div>
        <div class="col-xs-6 col-md-3">
            <h6>My Account</h6>
            <ul>
                <li><a href="#">My Account</a></li>
                <li><a href="#">Login</a></li>
                <li><a href="#">My Cart</a></li>
                <li><a href="#">Checkout</a></li>
            </ul>
        </div>
        <div class="col-xs-6 col-md-3">
            <h6>Information</h6>
            <ul>
                <li><a href="#">Sitemap</a></li>
                <li><a href="#">Payment Option</a></li>
                <li><a href="#">FAQ's</a></li>
            </ul>
        </div>
        <div class="col-xs-6 col-md-3">
            <h6>Social Media</h6>
            <ul>
                <li><a href="#" >Facebook</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">Pinterest</a></li>
                <li><a href="#">Twitter</a></li>
            </ul>
        </div>
    </div>
</footer>
<div class="powerd container text-center">
    <div class="pull-left">&copy; 2016 easyrental.com. All Rights Reserved</div>
    <div class="pull-right"><a href="http://kwebmaker.com" target="_blank">Kwebmaker&trade;</a></div>
</div>
<script>
CI_ROOT = "<?php echo base_url();?>";
</script>
<script src="<?php echo base_url()?>assets/js/common.js"></script>
<script src="<?php echo base_url()?>assets/js/app.js"></script>
<script src="<?php echo base_url()?>assets/js/allScript.js"></script>
<?php if(isset($scripts)){ ?><script src="<?php echo base_url()?>assets/resources/<?php echo $scripts ?>.js"></script><?php } ?>