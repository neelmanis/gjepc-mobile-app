<header>
	<div class="logo"> <a href="<?php echo base_url()?>"><img src="<?php echo base_url()?>assets/images/logo.png"></a> </div>
	<a id="touch-menu" class="mobile-menu" href="#"><i class="fa fa-2x fa-reorder"></i></a>
	</div>
	<ul class="menu">
		<li><a href="productList.php"><img src="<?php echo base_url()?>assets/images/menuIcons/1.png">List Your Products</a></li>
		<li><a href="#"><img src="<?php echo base_url()?>assets/images/menuIcons/2.png">Categories</a>
			<ul>
				<?php $categories = Modules::run('category/_getWhere', array('isActive'=>'1','parentId'=>'1','isMenu'=>'1'))?>
				<?php foreach($categories as $category): $imgName = $category->icon; $slug = $category->slug; ?>
				<li><a href='<?php echo base_url("category/view/$slug") ?>'><img src='<?php echo base_url("uploads/category/icons/$imgName")?>'><?php echo $category->name ?></a></li>
				<?php endforeach ?>
			</ul>
		</li>
		<!--<li><a href="register.php"><img src="images/menuIcons/3.png">Sign up</a></li>-->
		<?php if(Modules::run('site_security/isLoggedIn')) : ?>
		<li><a href="<?php echo base_url('users/logout') ?>"><img src="<?php echo base_url()?>assets/images/menuIcons/3.png">Logout</a></li>
		<?php else: ?>
		<li><a href="<?php echo base_url('users/login') ?>"><img src="<?php echo base_url()?>assets/images/menuIcons/3.png">Login</a></li>
		<?php endif; ?>
		<li><a href="#"><img src="<?php echo base_url()?>assets/images/menuIcons/4.png">Cart (0)</a></li>
	</ul>
</header>