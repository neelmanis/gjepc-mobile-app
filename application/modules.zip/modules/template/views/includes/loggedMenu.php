<div class="container-fluid dashboardLinkTop">
    <div class="container">
        <a href="<?php echo base_url('dashboard/user') ?>" <?php echo ($page=='Dashboard')? 'class="active"' :'' ?>>Dashboard</a>
        <a href="your_listing.php">Your Listing</a>
        <a href="borrow_approval_pending.php">You borrow</a>
        <a href="wishlist.php">Wish Lists</a>
        <a href="Profile_Edit_Profile.php">Profile</a>
    </div>
</div>