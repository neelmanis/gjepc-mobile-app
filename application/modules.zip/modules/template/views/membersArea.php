<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>assets/images/favicon.ico">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/common.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/responsive.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <title><?php echo $title ?></title>
</head>
<body>
<div class="preloader"><div></div></div>
<?php $this->load->view('includes/header',array('class'=>'')); ?>
<main>
    <?php $this->load->view('includes/loggedMenu',array('class'=>'')); ?>
    <section class="inner">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <?php if(isset($leftPanel) && $leftPanel): ?>
                        <?php if(!isset($module)){
                            $module = $this->uri->segment(1);
                        }

                        if( $module != '' ){
                            $path = $module. '/' . $leftPanel;
                            echo $this->load->view($path);
                        }
                        ?>
                    <?php endif; ?>
                </div>
                <div class="col-sm-9">
                    <?php
                    if( !empty($module) && !empty($viewFile) ){
                        $path = $module. '/' . $viewFile;
                        $this->load->view($path);
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>
</main>
<?php echo $this->load->view('includes/footer',array('class'=>'')); ?>
</body>
</html>
