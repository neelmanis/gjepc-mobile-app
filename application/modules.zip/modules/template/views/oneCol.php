<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>assets/images/favicon.ico">
	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/common.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/responsive.css">
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<title><?php echo $title ?></title>
</head>
<body>
<div class="preloader"><div></div></div>
<?php $this->load->view('includes/header',array('class'=>''));  ?>
<?php if(!isset($haveBanner)) { ?>
<main> <?php } ?>

	<?php if(!empty($breadcrumb)): ?>
	<div class="container-fluid breadcrumb">
		<div class="container"> <a href="<?php echo base_url()?>">Home</a><span><?php echo $breadcrumb; ?></span> </div>
	</div>
	<?php endif; ?>
	<?php
	if(!isset($module)){
		$module = $this->uri->segment(1);
		if(empty($module))
			$module = 'welcome';
	}

	if(!isset($viewFile)){
		$viewFile = $this->uri->segment(2);
	}

	if( $module != '' && $viewFile != '' ){
		$path = $module. '/' . $viewFile;
		echo $this->load->view($path);
	}
	?>
<?php if(!isset($haveBanner)) { ?>
</main> <?php } ?>

<?php echo $this->load->view('includes/footer',array('class'=>'')); ?>
</body>
</html>
