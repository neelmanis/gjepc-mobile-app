<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Users extends MX_Controller
{
	function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('mdl_users');
	}

	function _getWhere($data = array()){
		return $this->mdl_users->get_where($data);
	}

	function everify($cipher = ''){
		$verification = $this->mdl_users->everify($cipher);
		if($verification){
			$template = 'oneCol';
			$data['viewFile'] = 'verifyEmail';
			$data['breadcrumb'] = "Email Verified";
			$data['title'] = 'EASYRENTIL - VERIFICATION';
			$data['message'] = $verification;
			echo Modules::run('template/'.$template, $data);
		}
		else
			show_404();
	}

	function sendlink($cipher = ''){
		if(!empty($cipher) && $this->input->is_ajax_request()){
			echo $this->mdl_users->_initiateEmailVerification($cipher);
		}
		else
			show_404();
	}

	function login(){
		$data = array();
		$template = 'oneCol';
		$data['viewFile'] = 'login';
		$data['breadcrumb'] = "Login";
		$data['title'] = 'EASYRENTIL - LOGIN';
		$data['scripts'] = 'auth';
		echo Modules::run('template/'.$template, $data);
	}

	function register($uri = '')
	{
		$data = array();
		$template = 'oneCol';
		$data['viewFile'] = 'register';
		$data['breadcrumb'] = "Register";
		$data['title'] = 'EASYRENTIL - REGISTER';
		$data['scripts'] = 'register';
		echo Modules::run('template/' . $template, $data);
	}

	function validate(){
		if(isset($_POST['isAjax'])){
			$result = $this->mdl_users->validate();
			if( $result == 'validationErrors')
				echo validation_errors('<p>','</p>');
			elseif( $result == 'failed')
				echo '"Oops. Something went wrong. Please try again later."';
			elseif( $result == 'success')
				echo 'success';
			else
				echo $result;
		}
		else
			redirect('/');
	}

	function _authorize($data = array()){
		if(sizeof($data)){
			return $this->mdl_users->_authorize($data);
		}
		else
			return 'failed';
	}

	function validatelogin(){
		if(isset($_POST['isAjax'])){
			if($this->mdl_users->validateLogin())
				echo $this->_authorize(array('email'=>$this->input->post('email'), 'password'=>$this->input->post('password')));
			else
				echo validation_errors('<p>','</p>');
		}
		else
			redirect('/');
	}

	function logout(){
		$this->session->unset_userdata('userData');
		$this->session->sess_destroy();
		redirect('users/login','refresh');
	}

	function lists($approved = 'new'){
		$template = 'admin';
		$data['viewFile'] = "lists";
		$data['page'] = 'users';
		$data['menu'] = 'lists';
		$data['approved'] = $approved;

		echo Modules::run('template/'.$template, $data);
	}

	function info(){
		if(Modules::run('site_security/is_admin')):
			$new = array(); $json = array();
			$array = $this->uri->uri_to_assoc();

			$approved = (array_key_exists('as', $array)) ? (($array['as'] == 'new') ? 'P': (($array['as'] == 'approved') ? 'Y' : 'N'))  : 'P';

			$users = $this->mdl_users->_conditions(array('approved'=>$approved));
			foreach($users as $user){
				$name = $user->firstName.' '.$user->MiddleName.' '.$user->lastName;
				$new['name'] = $name;
				$new['email'] = $user->email;
				$new['emailVerified'] = ($user->emailVerified == 'Y') ? 'Verified': 'Not Verified';
				$new['mobileNo'] = $user->mobileNo;
				$new['phoneVerified'] = ($user->phoneVerified == 'Y') ? 'Verified': 'Not Verified';
				$new['regId'] = $user->regId;
				$new['modifiedDate'] = $user->modifiedDate;
				$new['cipher'] = $this->mdl_users->_mc_encrypt($user->email, ENCRYPTION_KEY);

				array_push($json, $new);
			}
			echo json_encode($json);
		else:
			show_404();
		endif;
	}
}