<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Mdl_users extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	function get_table() {
		$table = "registration";
		return $table;
	}

	function _makeHash($password){
		$hashPassword = sha1($password);
		return $hashPassword;
	}

	function _mc_encrypt($string, $key){
		return rtrim(trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $string, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)))),'=');
	}

	function _mc_decrypt($string, $key){
		return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, base64_decode($string), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
	}

	function everify($cipher){
		if(!empty($cipher)) {
			$email = $this->_mc_decrypt($cipher, ENCRYPTION_KEY);
			if(!preg_match('/^(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){255,})(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){65,}@)(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22))(?:\.(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-[a-z0-9]+)*\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-[a-z0-9]+)*)|(?:\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\]))$/iD', $email))
				return FALSE;

			$result = $this->get_where(array('email'=>$email));
			if(!$result || !sizeof($result))
				return FALSE;
			else {

				if($result[0]->emailVerified == 'Y')
					return 'Your Email has already been Verified';

				$regId = $result[0]->regId;
				if($this->_update($regId, array('emailVerified'=>'Y')))
					return 'Your Email verification is successful';

				return FALSE;
			}
		}
		else
			return FALSE;
	}

	function _initiatePhoneVerification($phoneNo = ''){
		if(!empty($phoneNo)){
			return TRUE;
		}
		else
			return FALSE;
	}

	function _initiateEmailVerification($cipher){
		$email = $this->_mc_decrypt($cipher, ENCRYPTION_KEY);
		if(!preg_match('/^(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){255,})(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){65,}@)(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22))(?:\.(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-[a-z0-9]+)*\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-[a-z0-9]+)*)|(?:\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\]))$/iD', $email))
			return 'Email Invalid';

		$result = $this->get_where(array('email'=>$email));
		if(!$result || !sizeof($result))
			return 'Email Not Found';
		else{
			//Email Exists so sent email for verification
			$info['viewFile'] = 'emailVerify';
			$info['encryptedString'] = $cipher;
			$info['receiverEmail'] = $email;
			$info['subject'] = 'EasyRentil - Verify your Email';

			if(Modules::run('email/_mailer', $info))
				return 'success';
			else
				return 'Sorry, verification mail could not be sent, please try again after sometime';
		}
	}

	function _initiateDetailsVerification($email = '', $phoneNo = ''){
		if(!empty($email) && !empty($phoneNo)){

		}
		else
			return FALSE;
	}

	function _tasks($info = array()){
		// task1 : create directory in uploads for every new registration
		if(array_key_exists('regId', $info)){
			$regId = $info['regId'];
			if(!file_exists("uploads/users/$regId"))
				mkdir("uploads/users/$regId", 0755, true);
		}

		//task2 : set session variable for message shown on success
		$successMsg = 'Thanks for registering with us, We will notify you once your application is approved.<br>';
		$successMsg .= 'Please check your Email, for verification of your registered E-mail <br>';

		//uncomment once sms gateway has been integrated
		/*$successMsg .= 'An OTP is sent to your Mobile No. Please click on below link to Verify<br>';
		$successMsg .= '<a href="'. base_url("users/mverify") .'">Verify Phone No</a>';*/


		$this->session->set_flashdata('registered', $successMsg);

		//task3 : send Mail to verify email
		$string = $info['email'];
		$info['viewFile'] = 'signup';
		$info['encryptedString'] = $this->_mc_encrypt($string, ENCRYPTION_KEY);
		$info['receiverEmail'] = $info['email'];
		$info['subject'] = 'EasyRentil - Verification of Email and Phone No';

		//task4 : send OTP to verify phone No --- pls integrate SMS GATEWAY and accomplish this step

		$sendMail = Modules::run('email/_mailer', $info);
		return $sendMail;

	}

	function _insert($data) {
		$table = $this->get_table();
		return $this->db->insert($table, $data);
	}

	function _update($regId, $data) {
		$table = $this->get_table();
		$this->db->where('regId', $regId);
		return $this->db->update($table, $data);
	}

	function _delete($regId) {
		if($regId > 1):
			$table = $this->get_table();
			$this->db->where('regId', $regId);
			return $this->db->delete($table);
		else:
			return false;
		endif;
	}

	function get_where($filters = array()) {
		$table = $this->get_table();

		if(sizeof($filters)){
			$this->db->where($filters);

			$query = $this->db->get($table);
			return $query->result();
		}
		else
			return FALSE;
	}

	function _conditions($and = array(), $or = array()){
		$table = $this->get_table();
		$andconditon = FALSE; $orcondition = FALSE;

		if(sizeof($and)){
			$andconditon = TRUE;
			foreach($and as $key=>$value)
				$this->db->where($key, $value);
		}

		if(sizeof($or)){
			$orcondition = TRUE;
			foreach($or as $key=>$value)
				$this->db->or_where($key, $value);
		}

		if($orcondition || $andconditon){
			$query = $this->db->get($table);
			return $query->result();
		}

		return FALSE;
	}

	function checkGender($data){
		return ($data == 'M' || $data == 'F') ? TRUE : FALSE;
	}

	function checkDate($date){
		if (preg_match("/^(\d{2})-(\d{2})-(\d{4})$/", $date)) {
			if(checkdate(substr($date, 3, 2), substr($date, 0, 2), substr($date, 6, 4)))
				return true;
			else
				return false;
		} else {
			return false;
		}
	}

	function validateLogin(){
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|max_length[150]|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|min_length[8]|max_length[32]');
		if(!$this->form_validation->run())
			return FALSE;
		else{
			return TRUE;
		}
	}

	function _authorize($data = array()){
		$data['password'] = $this->_makeHash($data['password']);
		$details = $this->get_where($data);

		if(sizeof($details)){
			$as = $details[0]->approved; // checks admin approval status
			$a = $details[0]->status; // checks user account active or not
			$suspend = 'Your account has been temporarily suspended. Please contact EasyRentil Administrator.'; // status is de-active
			$apm = 'Your account is pending Admin approval'; // account is pending approval
			$adm = 'Your account was dissapproved, please contact EasyRentil Administrator'; // account is dissaproved msg

			$message = ($as == 'Y' && $a == 'Y') ? 'success': (($as == 'P' && $a == 'Y') ? $apm : (($as == 'N' && $a == 'Y') ? $adm : $suspend));
			if($message == 'success'){
				$regId = $details[0]->regId;
				$sessionData = array('regId'=>$regId);
				$this->session->set_userdata('customerData', $sessionData);
				return $message;
			}
			return $message;
		}
		else
			return '<p>Your Login Credentials appear to be invalid</p>';
	}

	function validate(){

		$this->form_validation->set_rules('firstName','First Name','trim|required|alpha|max_length[100]|xss_clean');
		$this->form_validation->set_rules('MiddleName','Middle Name','trim|required|alpha|max_length[100]|xss_clean');
		$this->form_validation->set_rules('lastName','Last Name','trim|required|alpha|max_length[100]|xss_clean');

		$this->form_validation->set_rules('building','Building','trim|required|max_length[100]|xss_clean');
		$this->form_validation->set_rules('street','Street','trim|required|max_length[100]|xss_clean');

		if($this->input->post('countryId') == 'NULL'){
			$this->form_validation->set_rules('otherCountries','Other Country','trim|required|max_length[100]|xss_clean');
			$this->form_validation->set_rules('otherStates','Other States','trim|required|max_length[100]|xss_clean');
			$this->form_validation->set_rules('otherCities','Other Country','trim|required|max_length[100]|xss_clean');
		}
		else
			$this->form_validation->set_rules('countryId','Country','trim|required|is_natural|xss_clean');

		if(isset($_POST['stateId']) && $_POST['stateId'] == 'NULL')
			$this->form_validation->set_rules('otherStates','Other States','trim|required|max_length[100]|xss_clean');
		elseif(isset($_POST['stateId']))
			$this->form_validation->set_rules('stateId','State','trim|required|is_natural|xss_clean');
		else
			$this->form_validation->set_rules('otherStates','Other States','trim|required|max_length[100]|xss_clean');

		if(isset($_POST['cityId']) && $_POST['cityId'] == 'NULL')
			$this->form_validation->set_rules('otherCities','Other City','trim|required|max_length[100]|xss_clean');
		elseif(isset($_POST['cityId']))
			$this->form_validation->set_rules('cityId','City','trim|required|is_natural|xss_clean');
		else
			$this->form_validation->set_rules('otherCities','Other City','trim|required|max_length[100]|xss_clean');


		$this->form_validation->set_rules('pincode','Pin Code','trim|required|numeric|max_length[6]|xss_clean');

		$this->form_validation->set_rules('mobileNo','Phone','trim|required|numeric|max_length[12]|xss_clean');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|max_length[150]|is_unique[registration.email]|xss_clean');

		$this->form_validation->set_rules('govID1','Government ID 1','trim|required|is_natural|xss_clean');
		if (empty($_FILES['govFile1']['name']) && !empty($_POST['govID1']))
			$this->form_validation->set_rules('govFile1', 'File for Government ID1', 'required');

		$this->form_validation->set_rules('govID2','Government ID 2','trim|required|is_natural|xss_clean');
		if (empty($_FILES['govFile2']['name']) && !empty($_POST['govID2']))
			$this->form_validation->set_rules('govFile2', 'File for Government ID2', 'required');

		$this->form_validation->set_rules('dateOfBirth','DOB','trim|required|callback_checkDate|xss_clean');
		$this->form_validation->set_rules('gender','Gender','trim|required|max_length[1]|callback_checkGender|xss_clean');

		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|min_length[8]|max_length[32]');
		$this->form_validation->set_rules('confirmpass', 'Confirm Password', 'trim|required|matches[password]|xss_clean|min_length[8]|max_length[32]');

		$this->form_validation->set_message('is_natural', 'PLease select from %s dropdown');
		$this->form_validation->set_message('checkGender', '%s is Invalid');
		$this->form_validation->set_message('checkDate', '%s is invalid, please use dd-mm-yyyy format');

		if(!$this->form_validation->run($this))
			return 'validationErrors';
		else{
			$insertdata = array();

			/*after form validation check for image validation if validated insert data else throw error*/
			$govID1 = upload(array('name'=>'govFile1', 'upload_path'=>'proofs/gov1'));
			if(array_key_exists('errors', $govID1))
				return 'Government ID 1: '.$govID1['errors'];
			$insertdata['govFile1'] = $govID1['filename'];

			$govID2 = upload(array('name'=>'govFile2', 'upload_path'=>'proofs/gov2'));
			if(array_key_exists('errors', $govID2)) {
				unlink($govID1['full_path']);
				return 'Government ID 2: ' . $govID2['errors'];
			}
			$insertdata['govFile2'] = $govID2['filename'];
			/* end of image assignment and validation */

			$insertdata['firstName'] = $this->input->post('firstName');
			$insertdata['MiddleName'] = $this->input->post('MiddleName');
			$insertdata['lastName'] = $this->input->post('lastName');
			$insertdata['building'] = $this->input->post('building');
			$insertdata['street'] = $this->input->post('street');

			/* setting array variables for inserting in database*/
			if($_POST['countryId'] != 'NULL')
				$insertdata['countryId'] = $this->input->post('countryId');

			if(isset($_POST['otherCountries']))
				$insertdata['otherCountries'] = $this->input->post('otherCountries');

			if(isset($_POST['stateId']) && $_POST['stateId'] != 'NULL')
				$insertdata['stateId'] = $this->input->post('stateId');

			if(isset($_POST['otherStates']))
				$insertdata['otherStates'] = $this->input->post('otherStates');

			if(isset($_POST['cityId']) && $_POST['cityId'] != 'NULL')
				$insertdata['cityId'] = $this->input->post('cityId');

			if(isset($_POST['otherCities']))
				$insertdata['otherCities'] = $this->input->post('otherCities');
			/* end for country, states and cities variable assignment */

			$insertdata['pincode'] = $this->input->post('pincode');
			$insertdata['mobileNo'] = $this->input->post('mobileNo');
			$insertdata['email'] = $this->input->post('email');
			$insertdata['govID1'] = $this->input->post('govID1');
			$insertdata['govID2'] = $this->input->post('govID2');
			$insertdata['dateOfBirth'] = date('Y-m-d', strtotime($_POST['dateOfBirth']));
			$insertdata['gender'] = $this->input->post('gender');
			$insertdata['password'] = $this->_makeHash($_POST['password']);
			$insertdata['createdDate'] = date('Y-m-d h:i:s');
			$insertdata['modifiedDate'] = date('Y-m-d h:i:s');


			if($this->_insert($insertdata)):
				$regId = $this->db->insert_id();
				$processInitiated = $this->_tasks(array('regId'=>$regId, 'email'=> $insertdata['email'], 'mobileNo'=>$insertdata['mobileNo']));
				//since entry is made if new registration dependency task fail still success is returned
				return ($processInitiated) ? 'success' : 'success';
			else:
				return 'failed';
			endif;
		}
	}
}