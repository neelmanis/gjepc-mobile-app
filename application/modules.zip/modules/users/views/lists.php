<div class="row mt">
    <div class="col-lg-12">
        <div class="alert alert-danger errorMsg hide alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <span class="message">"<b>Oops. </b>Something went wrong. Please try again later."</span>
        </div>
        <?php if(!empty($this->session->flashdata('success'))): ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $this->session->flashdata('success'); ?>
            </div>
        <?php endif; ?>

        <div class="content-panel">
            <h4>Registration - (<?php echo ucfirst($approved); ?>)</h4>
            <div class="showback">
                <div class="btn-group">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                        View <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="<?php echo base_url("users/lists/new"); ?>">New Registrations Pending Approval</a></li>
                        <li><a href="<?php echo base_url("users/lists/approved"); ?>">Approved Registration</a></li>
                        <li><a href="<?php echo base_url("users/lists/disapproved"); ?>">Disapproved Registration</a></li>
                    </ul>
                </div>
            </div>

            <section id="no-more-tables">
                <table class="table table-striped table-condensed cf" id='listTable'>
                    <thead class="cf">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Email status</th>
                        <th>Mobile</th>
                        <th>Mobile status</th>
                        <th>Modified Date</th>
                        <th><i class=" fa fa-edit"></i> Actions</th>
                    </tr>
                    </thead>
                </table>
            </section>
        </div>
    </div>
</div>
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form class="form-horizontal">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Delete State</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to <b class='name'></b> ?</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-default" data-dismiss="modal">Close</button>
                    <button class="btn btn-danger" id=''>Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    var messageElem = $('.message');
    var messageText = messageElem.html();

    $('#listTable').DataTable({
        stateSave: true,
        "ajax": {
            "url": baseUrl+"users/info/as/<?php echo $approved ?>",
            "dataSrc": "",
            "deferRender": true
        },
        "columns": [
            { "data": "name" },
            { "data": "email" },
            { "data": "emailVerified" },
            { "data": "mobileNo" },
            { "data": "phoneVerified" },
            { "data": "modifiedDate"},
            { "data": "regId" }
        ],
        "order": [[5, "desc"]],
        "columnDefs": [
            {
                "targets": [5],
                "visible": false,
                "searchable": false,
            },
            {
                "render": function ( data, type, row ) {
                    var url = baseUrl + 'users/sendlink/' + row.cipher;
                    var str = data + '<br><a class="help-block btn btn-primary btn-xs" href="' + url + '" title="Verify">Send Verification Link</a>';
                    return (row.emailVerified == 'Verified') ? data : str;
                },
                "targets": [1]
            },
            {
                "render": function ( data, type, row ) {
                    var url = baseUrl + 'users/edit/' + data;
                    var str = '<a class="deleterows btn btn-danger btn-xs" data-target="#deleteModal" data-toggle="modal" data-id="'+ data +'" data-text="' + row.name + '" title="Delete User"><i class="fa fa-trash-o"></i></a>';
                    str += ' <a class="btn btn-primary btn-xs" href="' + url + '" title="Edit User"><i class="fa fa-pencil"></i></a>';

                    return str;
                },
                "targets": [6]
            }
        ],
    });

    /* Setting up the delete button in modal box by adding id attribute to delete button in modal */
    jQuery(document).on('click', 'a.deleterows',function(){
        var $this = jQuery(this);
        var deleteModal = jQuery('#deleteModal');
        var text = $this.data('text');
        var dataid = $this.data('id');

        deleteModal.find('button.btn-danger').attr('id', dataid).end().find('b.name').text(text);
    })

    /* Click on delete button in delete Modal */
    jQuery('#deleteModal').find('button.btn-danger').on('click',function(e){
        e.preventDefault();
        var $this = jQuery(this);
        var id = $this.attr('id');

        $.ajax({
            url: baseUrl+'users/deluser/'+id,
            success: function(data){
                if(data == 'success'){
                    $this.siblings('button').trigger('click');
                    messageElem.closest('.errorMsg').addClass('hide');
                    location.reload(true);
                }
                else{
                    $this.siblings('button').trigger('click');
                    messageElem.html(messageText).closest('.errorMsg').removeClass('alert-success hide');
                }
            }
        })
    });

    $(document).on('click', '.help-block', function(e){
        e.preventDefault();
        var $this = $(this);
        var vurl = $(this).attr('href');
        $.ajax({
            url: vurl,
            type: 'GET',
            beforeSend: function (xhr, opts) {
                $this.removeClass('help-block');
            },
            success: function(data){
                console.log(data);
                $this.addClass('help-block');
                if(data != 'success')
                    messageElem.html(data).closest('.errorMsg').removeClass('alert-success hide').addClass('alert-danger');
                else
                    messageElem.html('Email has been sent for Verification').closest('.errorMsg').removeClass('alert-danger hide').addClass('alert-success');

            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    });
</script>