<section class="inner">
    <div class="container">
        <div class="alert alert-success alert-dismissable">
            <?php echo $this->session->flashdata('registered'); ?>
        </div>
        
        <div class="row loginRegister">
            <div class="col-sm-6">
                <form class="FlowupLabels" id="login">
                    <h3>Login</h3>
                    <div class="form-group fl_wrap">
                        <label class="fl_label" for="eMail">E-mail address</label>
                        <input type="text" class="form-control fl_input" id="eMail" name="email">
                    </div>
                    <div class="form-group fl_wrap">
                        <label class="fl_label" for="password">Password</label>
                        <input type="password" class="form-control fl_input" id="password" name="password">
                        <a class="help-block" href="#">Forgot Password</a> </div>

                    <div class="form-group">
                        <input type="submit" class="btn btnBlock" value="Login">
                    </div>
                    <div class="form-group"><p>Don't have an account yet? <a href="<?php echo base_url('users/register') ?>">Join Now</a></p></div>
                </form>
            </div>

        </div>
    </div>
</section>