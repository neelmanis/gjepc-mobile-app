<section class="inner">
	<div class="container">
		<div class="row loginRegister">
			<div class="col-sm-6">
				<form class="FlowupLabels" id="registerForm">
					<h3>Registration</h3>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="firstName">First Name</label>
						<input type="text" class="form-control fl_input" id="firstName" name="firstName">
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="middleName">Middle Name</label>
						<input type="text" class="form-control fl_input" id="middleName" name="MiddleName">
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="lastName">Last Name</label>
						<input type="text" class="form-control fl_input" id="lastName" name="lastName">
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="building">Building</label>
						<input type="text" class="form-control fl_input" id="building" name="building">
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="street">Street</label>
						<input type="text" class="form-control fl_input" id="street" name="street">
					</div>
					<div class="form-group fl_wrap">
						<select class="form-control fl_input" name="countryId">
							<option value="">Select Country</option>
						</select>
					</div>

					<div class="form-group fl_wrap" id="state"></div>

					<div class="form-group fl_wrap" id="city"></div>

					<div class="form-group fl_wrap">
						<label class="fl_label" for="pincode">Pin Code</label>
						<input type="text" class="form-control fl_input" id="pincode" name="pincode">
					</div>
					<div class="form-group fl_wrap contact-group">
						<label class="fl_label" for="mobile">Phone</label>
						<input type="text" class="form-control fl_input" id="mobile" name="mobileNo">
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="eMail">E-mail address</label>
						<input type="text" class="form-control fl_input" id="eMail" name="email">
					</div>
					<div class="form-group fl_wrap">
						<select class="form-control fl_input govIds" name="govID1">
							<option value="">Goverment ID 1</option>
						</select>
					</div>
					<div class="form-group fl_wrap uploadDocument">
						<input type="file" class="form-control fl_input" name="govFile1">
					</div>
					<div class="form-group fl_wrap">
						<select class="form-control fl_input govIds" name="govID2">
							<option value="">Goverment ID 2</option>
						</select>
					</div>
					<div class="form-group fl_wrap uploadDocument">
						<input type="file" class="form-control fl_input" name="govFile2">
					</div>

					<div class="form-group fl_wrap">
						<label class="fl_label" for="DOB">Date of Birth</label>
						<input type="text" class="form-control fl_input" id="DOB" name="dateOfBirth">
					</div>
					<div class="form-group container-fluid">
						<div class="row">
							<label class="col-xs-12 control-label">Gender</label>
							<div class="col-xs-6">
								<div class="radio">
									<label>
										<input type="radio" value="M" name="gender">
										Male</label>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="radio">
									<label>
										<input type="radio" value="F" name="gender">
										Female</label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="password">Password</label>
						<input type="password" class="form-control fl_input" id="password" name="password">
					</div>
					<div class="form-group fl_wrap">
						<label class="fl_label" for="conPass">Confirm Password</label>
						<input type="password" class="form-control fl_input" id="conPass" name="confirmpass">
					</div>
					<div class="form-group">
						<input type="submit" class="btn btnBlock" value="Register">
					</div>
					<div class="form-group">
						<p>Already have an account? <a href="<?php echo base_url('users/login') ?>">Sign In</a></p>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>