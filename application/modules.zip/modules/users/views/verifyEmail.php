<div class="container">
    <h3><?php echo $message?>, Please Click here to <a href="<?php echo base_url('users/login')?>">Login</a></h3>
</div>