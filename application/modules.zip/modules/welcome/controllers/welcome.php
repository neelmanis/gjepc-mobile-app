<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends MX_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('mdl_welcome');
	}
	
	function index()
	{
		$gallery = $this->mdl_welcome->getBanner();
		$data['banner'] = $gallery;
		$template = 'oneCol';
		$data['title'] = 'Welcome To Easy Rentil';
		$data['viewFile'] = 'index';
		$data['isHomePage'] = TRUE;	
		$data['haveBanner'] = TRUE;	
		echo Modules::run('template/'.$template, $data); 
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */